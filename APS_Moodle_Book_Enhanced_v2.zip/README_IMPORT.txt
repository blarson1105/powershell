Advanced PowerShell Scripting Moodle Book Import Package
Enhanced Student-Friendly Edition — v2

Changes in v2:
- Removed all Course Creator Traceability (📚) callout blocks
- Fixed CTSSB alignment: Ch3 K2 tag removed, Ch5 K9 LO made explicit
- Added one hands-on exercise per chapter (Chapters 1–5)
- Exercise for Chapter 6 not added (capstone chapter — exercises are the capstone itself)

Styling (carried from v1):
- VS Code Dark+ accurate token coloring
- Code blocks with window chrome (title bar, traffic light dots, language label)
- Polished callout boxes (info, success, question, exercise)
- Clean inline code badges
- Zebra-striped tables with hover state
- Fixed duplicate style attributes on table cells
- Consistent CSS class-based styling

Import: Moodle > Book > Import chapter > Upload individual HTML files

# Capstone Reference — Clean Environment Testing Runbook

**Purpose:** Step-by-step validation of `CapstoneTools.psm1` and `Invoke-Capstone.ps1` against a fresh CVTE range environment.

**Prerequisites:**
- Fresh range image (Ops, System-1, System-2, System-3 reset or rebuilt)
- `CapstoneTools.psm1` and `Invoke-Capstone.ps1` ready to copy to Ops
- Sysmon files available for staging (`Sysmon64.exe`, `sysmonconfig-export.xml`)

---

## 🚨 Rules For This Run

1. **Do not deviate from the steps.** If something fails, stop and document — don't improvise.
2. **Do not reuse `$cred` across steps unless specified.** Always build credentials explicitly with the `New-Object PSCredential` pattern. Avoid the `Get-Credential` GUI prompt.
3. **Copy-paste full commands as single lines.** Multi-line pastes mangle in the Windows console.
4. **Record every test outcome.** Success or failure, paste the output into a scratch document.

---

## Phase 0 — Environment Verification (On Ops)

### 0.1 Confirm you're on Ops

```powershell
hostname
$PSVersionTable.PSVersion
```

**Expected:** hostname `Ops` (or whatever the range image names it — note the actual value), PSVersion 7.x.

**If PSVersion shows 5.1:** you opened Windows PowerShell, not PowerShell 7. Close and open `pwsh` instead.

### 0.2 Confirm scripts are staged

```powershell
cd C:\Users\Student
Get-ChildItem CapstoneTools.psm1, Invoke-Capstone.ps1 | Select-Object Name, Length, LastWriteTime
```

**Expected:** both files present, `CapstoneTools.psm1` ~12 KB, `Invoke-Capstone.ps1` ~6.5 KB.

### 0.3 Confirm WinRM service on Ops

```powershell
Get-Service WinRM
```

**Expected:** Status `Running`. If Stopped: `Start-Service WinRM`.

### 0.4 Confirm TrustedHosts

```powershell
(Get-Item WSMan:\localhost\Client\TrustedHosts).Value
```

**Expected:** contains `System-1,System-2,System-3,Depot` or `*`.

**If empty or wrong:**
```powershell
Set-Item WSMan:\localhost\Client\TrustedHosts -Value "System-1,System-2,System-3,Depot" -Force
```

### 0.5 Confirm all three targets are reachable

```powershell
'System-1','System-2','System-3' | ForEach-Object { try { $r = Test-WSMan -ComputerName $_ -ErrorAction Stop; "$_ : OK" } catch { "$_ : FAIL - $($_.Exception.Message)" } }
```

**Expected:** all three return `OK`.

**If any return `FAIL`:** stop here. Do not proceed until all three are reachable. WinRM transport has to work before auth can succeed.

---

## Phase 1 — Credential Setup

### 1.1 Verify `student` account exists and is admin on every target

This is a one-time sanity check. On each target's console (or via another means if you have access), run:

```powershell
net user student
```

**Expected on each target:**
- `Account active: Yes`
- `Local Group Memberships: *Administrators` present
- `Password last set: [recent date]`

**Record the password you set.** Same password on all three targets. Use something simple for testing — you can rotate later:

```powershell
Set-LocalUser -Name student -Password (ConvertTo-SecureString 'CapstoneTest1!' -AsPlainText -Force)
```

Run that on System-1, System-2, and System-3 — identical password.

### 1.2 Build scoped credential on Ops (do NOT use Get-Credential GUI)

**This is the pattern that worked in prior testing:**

```powershell
$password = ConvertTo-SecureString 'CapstoneTest1!' -AsPlainText -Force
$cred = New-Object System.Management.Automation.PSCredential('System-1\student', $password)
$cred.UserName
```

**Expected:** `$cred.UserName` returns `System-1\student` with the prefix.

> **Note on credential scoping in workgroup:** The `System-1\` prefix is required so NTLM negotiates against System-1's SAM rather than Ops's. A bare `student` username fails even when passwords match.

---

## Phase 2 — Auth Smoke Tests (Before Any Module Code)

Do these before touching the module. If these fail, the module will fail — no point testing the module until basic auth works.

### 2.1 PSSession smoke test

```powershell
$s = New-PSSession -ComputerName System-1 -Credential $cred
$s
Remove-PSSession $s
```

**Expected:** session object prints with State `Opened`, then cleanly removes.

**If "Access is denied":**
1. Immediately go to System-1 console and run: `Get-WinEvent -FilterHashtable @{LogName='Security'; Id=4625; StartTime=(Get-Date).AddMinutes(-5)} -MaxEvents 3 | Format-List TimeCreated, Message`
2. Look at the `Account Domain` field in the message. If it shows anything other than `System-1`, the credential prefix is being stripped somewhere.
3. Stop. Document the failure. Do not continue.

### 2.2 CimSession smoke test

```powershell
$cs = New-CimSession -ComputerName System-1 -Credential $cred -Authentication Negotiate
$cs
Remove-CimSession $cs
```

**Expected:** CimSession object with Protocol `WSMAN`, then cleanly removes.

**If fails:** check which credential scope got rejected. Same diagnostic pattern as 2.1.

### 2.3 Repeat 2.1 for System-2 and System-3

You need to rebuild the credential for each target (because the `\` prefix is target-specific):

```powershell
$cred2 = New-Object System.Management.Automation.PSCredential('System-2\student', $password)
$s = New-PSSession -ComputerName System-2 -Credential $cred2
$s
Remove-PSSession $s
```

```powershell
$cred3 = New-Object System.Management.Automation.PSCredential('System-3\student', $password)
$s = New-PSSession -ComputerName System-3 -Credential $cred3
$s
Remove-PSSession $s
```

**If any fail:** same diagnostic. Don't proceed.

> **Credential scoping problem for orchestrator:** The scoped-credential-per-target pattern means the orchestrator can't use one `$cred` against multiple hosts. Either (a) each target needs a separately-scoped credential, (b) we use the computer-name-agnostic scope `.\student` (local SAM on each target), or (c) we accept DC integration as the clean fix. This is the decision point to revisit with Parsons after this test round. For today's test, use one credential at a time to validate the code paths.

---

## Phase 3 — Module Function Standalone Tests

### 3.1 Import the module

```powershell
Import-Module C:\Users\Student\CapstoneTools.psm1 -Force
Get-Command -Module CapstoneTools
```

**Expected:** three functions listed — `Get-RemoteProcessInfo`, `Get-RemoteServiceInfo`, `Install-SysmonRemote`.

### 3.2 Test Get-RemoteServiceInfo

```powershell
Get-RemoteServiceInfo -ComputerName System-1 -Credential $cred | Measure-Object
```

**Expected:** count around 200-300.

### 3.3 Test Get-RemoteProcessInfo

```powershell
Get-RemoteProcessInfo -ComputerName System-1 -Credential $cred | Measure-Object
```

**Expected:** count around 100-200.

### 3.4 Spot-check data quality

```powershell
Get-RemoteProcessInfo -ComputerName System-1 -Credential $cred | Select-Object -First 3 | Format-List
```

**Expected:** PSCustomObject with fields populated. System processes (PID 0, 4) may have blank CommandLine and UserName — that's normal.

### 3.5 Stage Sysmon on Ops

```powershell
$sysmonDir = 'C:\Tools\Sysmon'
New-Item -ItemType Directory -Path $sysmonDir -Force | Out-Null
Invoke-WebRequest -Uri 'https://download.sysinternals.com/files/Sysmon.zip' -OutFile "$sysmonDir\Sysmon.zip"
Expand-Archive "$sysmonDir\Sysmon.zip" -DestinationPath $sysmonDir -Force
Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/SwiftOnSecurity/sysmon-config/master/sysmonconfig-export.xml' -OutFile "$sysmonDir\sysmonconfig-export.xml"
Get-ChildItem $sysmonDir
```

**Expected:** `Sysmon64.exe` and `sysmonconfig-export.xml` both present.

### 3.6 Test Install-SysmonRemote

**Important:** pass **full file paths**, not directory paths:

```powershell
Install-SysmonRemote -ComputerName System-1 -Credential $cred -SysmonBinaryPath 'C:\Tools\Sysmon\Sysmon64.exe' -SysmonConfigPath 'C:\Tools\Sysmon\sysmonconfig-export.xml'
```

**Expected:** `Status: Success`, `ServiceState: Running`.

### 3.7 Verify Sysmon is actually running on System-1

```powershell
Invoke-Command -ComputerName System-1 -Credential $cred -ScriptBlock { Get-Service -Name Sysmon64 -ErrorAction SilentlyContinue }
```

**Expected:** Sysmon64 service with Status `Running`.

### 3.8 Clean up sessions

```powershell
Get-CimSession | Remove-CimSession
Get-PSSession | Remove-PSSession
```

---

## Phase 4 — Orchestrator Tests

### 4.1 Orchestrator against a single target (no deploy)

```powershell
$modulePath = (Resolve-Path C:\Users\Student\CapstoneTools.psm1).Path
.\Invoke-Capstone.ps1 -ComputerName 'System-1' -Credential $cred -ModulePath $modulePath -Verbose
```

**Expected:** `1 succeeded, 0 failed`. Table shows `ProcessCount` and `ServiceCount` populated.

**Note on multi-target with scoped credentials:** The current credential is scoped to `System-1\student` only. To test against multiple hosts in parallel, you'll need to decide on the credential strategy first. If auth works with `.\student` scope, rebuild the credential that way and proceed.

### 4.2 Try .\ scoping for multi-target

```powershell
$dotCred = New-Object System.Management.Automation.PSCredential('.\student', $password)
$s = New-PSSession -ComputerName System-1 -Credential $dotCred
$s
Remove-PSSession $s
```

**If this works:** `.\student` is the portable form. Use it for multi-target tests.

**If it fails:** workgroup auth will not support multi-target with a single credential. The DC question becomes operational.

### 4.3 If 4.2 worked, orchestrator against multiple targets

```powershell
.\Invoke-Capstone.ps1 -ComputerName 'System-1','System-2','System-3' -Credential $dotCred -ModulePath $modulePath -Verbose
```

**Expected:** `3 succeeded, 0 failed`.

### 4.4 Orchestrator with deploy across multiple targets

```powershell
.\Invoke-Capstone.ps1 -ComputerName 'System-1','System-2','System-3' -Credential $dotCred -ModulePath $modulePath -DeploySysmon -SysmonBinaryPath 'C:\Tools\Sysmon\Sysmon64.exe' -SysmonConfigPath 'C:\Tools\Sysmon\sysmonconfig-export.xml'
```

**Expected:** all three targets show `SysmonDeployed: True`, `SysmonState: Running`.

### 4.5 Induced-failure test

```powershell
.\Invoke-Capstone.ps1 -ComputerName 'System-1','NonExistent-99','System-3' -Credential $dotCred -ModulePath $modulePath
```

**Expected:** `2 succeeded, 1 failed`. `NonExistent-99` shows an error message but does not crash the run.

### 4.6 Timing comparison (optional)

```powershell
Measure-Command { .\Invoke-Capstone.ps1 -ComputerName 'System-1','System-2','System-3' -Credential $dotCred -ModulePath $modulePath -ThrottleLimit 3 }
```

```powershell
Measure-Command { .\Invoke-Capstone.ps1 -ComputerName 'System-1','System-2','System-3' -Credential $dotCred -ModulePath $modulePath -ThrottleLimit 1 }
```

**Expected:** throttle 3 is materially faster than throttle 1.

---

## Phase 5 — Cleanup

```powershell
Get-CimSession | Remove-CimSession
Get-PSSession | Remove-PSSession
Remove-Variable cred, cred2, cred3, dotCred, password -ErrorAction SilentlyContinue
```

---

## 📋 What To Report Back

For each phase, record:

- ✅ Pass — move on
- ⚠️ Partial — which sub-step worked vs. failed
- ❌ Fail — exact error message, which step

Specifically, come back with:

1. **Phase 0 result** — all clean, or which check failed
2. **Phase 2.1–2.3 results** — PSSession to each target with scoped `System-1\student`, `System-2\student`, `System-3\student` credentials
3. **Phase 3 results** — Get-*, Install-Sysmon against System-1
4. **Phase 4.2 result** — does `.\student` scoping work? This is the key finding for multi-target parallel operation.
5. **Phase 4.3–4.5 results** if 4.2 worked
6. **Any unexpected behavior**

---

## 🔥 Pre-Identified Fire Zones

Known places this can go wrong, ordered by how likely:

| # | Failure | Diagnostic |
|---|---|---|
| 1 | Password mismatch across targets | Reset explicitly with the same plaintext password on all three |
| 2 | Credential scope issue | Confirm `$cred.UserName` shows the expected prefix before use |
| 3 | `LocalAccountTokenFilterPolicy` missing | Check on target: `Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System LocalAccountTokenFilterPolicy` — should be 1 |
| 4 | WinRM not running / wrong listener | `Get-Service WinRM` and `winrm enumerate winrm/config/listener` |
| 5 | 4625 events show wrong account domain | Indicates credential scoping is being stripped — possibly a Sysmon tamper-protect issue, possibly Windows creds UI behavior |
| 6 | Sysmon install path treated as directory | Pass full file path, not directory |
| 7 | Multi-target with scoped cred fails | Expected — scoped credentials are target-specific. Use `.\student` form or accept single-target testing |

---

*End of runbook*

# Chapter 3 Exercise: Remote Connectivity Validator (Solution)
# Confirms connectivity, identity, and security modes for Capstone readiness.

# --- Part 1: Connectivity Validator ---
$Targets = @('System-1', 'System-2', 'System-3', 'Depot')

$Results = foreach ($Target in $Targets) {
    try {
        # 1. Verify WinRM reachability
        $null = Test-WSMan -ComputerName $Target -ErrorAction Stop
        
        # 2. Gather remote context
        $RemoteContext = Invoke-Command -ComputerName $Target -ScriptBlock {
            [pscustomobject]@{
                User = whoami
                Mode = $ExecutionContext.SessionState.LanguageMode
            }
        } -ErrorAction Stop

        # 3. Return success object
        [pscustomobject]@{
            ComputerName   = $Target
            WinRMReachable = $true
            RemoteUser     = $RemoteContext.User
            LanguageMode   = $RemoteContext.Mode
            Error          = $null
        }
    }
    catch {
        # 4. Capture failures for offline or restricted hosts
        [pscustomobject]@{
            ComputerName   = $Target
            WinRMReachable = $false
            RemoteUser     = $null
            LanguageMode   = $null
            Error          = $_.Exception.Message
        }
    }
}

# 5. Display connectivity report
Write-Host "`n--- Remote Connectivity Audit ---" -ForegroundColor Cyan
$Results | Format-Table -AutoSize

# --- Part 2: Deployment and Scoping (System-1) ---
# This simulates the deployment patterns required for Rubric Item R3
try {
    Write-Host "`n--- Deployment & Scoping Test (System-1) ---" -ForegroundColor Cyan
    
    # 1. Open persistent session
    $S = New-PSSession -ComputerName 'System-1' -ErrorAction Stop

    # 2. Local variable for scoping test
    $DeploymentID = "TASK-001-SYSMON"

    # 3. Use $using: to bridge the execution context
    Invoke-Command -Session $S -ScriptBlock {
        $RemoteUser = whoami
        $RemoteHost = hostname
        Write-Host "Connected as $RemoteUser on $RemoteHost" -ForegroundColor Green
        Write-Host "Deployment ID from Ops: $($using:DeploymentID)" -ForegroundColor Yellow
    }

    # 4. Close session
    Remove-PSSession $S
    Write-Host "Session closed successfully."
}
catch {
    Write-Warning "System-1 Deployment Test Failed: $($_.Exception.Message)"
}

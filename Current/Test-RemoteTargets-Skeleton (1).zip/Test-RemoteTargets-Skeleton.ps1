# Chapter 3 Exercise: Remote Connectivity Validator (Skeleton)
# Goals: Verify WinRM, check LanguageMode, and practice deployment patterns.

# --- Part 1: Connectivity Validator ---
# Define the targets array
$Targets = @('System-1', 'System-2', 'System-3', 'Depot')

$Results = foreach ($Target in $Targets) {
    try {
        # 1. Test WinRM reachability using Test-WSMan
        # Use -ErrorAction Stop to ensure failures go to the catch block
        
        # 2. Gather remote context via Invoke-Command
        # Retrieve 'whoami' and '$ExecutionContext.SessionState.LanguageMode'
        
        # 3. Return a successful [pscustomobject]
        # Properties: ComputerName, WinRMReachable, RemoteUser, LanguageMode, Error
    }
    catch {
        # 4. Handle failures and return a failure [pscustomobject]
    }
}

# 5. Display results in a table
$Results | Format-Table -AutoSize

# --- Part 2: Deployment and Scoping (System-1) ---
# 1. Open a persistent session to System-1

# 2. Define a local variable to test scoping
$LocalTest = "Authorized Deployment from Ops"

# 3. Use Invoke-Command -Session with the $using: modifier
# Verify the remote user and the value of $LocalTest

# 4. Clean up the session

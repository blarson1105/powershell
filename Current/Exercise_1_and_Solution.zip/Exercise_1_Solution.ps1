function Get-SystemSnapshot {
    param(
        # Default value of $env:COMPUTERNAME
        [string]$ComputerName = $env:COMPUTERNAME
    )

    try {
        # Decide execution context: local vs. remote
        if ($ComputerName -eq $env:COMPUTERNAME) {
            # Local query: Omit -ComputerName to keep the connection local
            $OS = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
        }
        else {
            # Remote query: Target specific host with terminating error handling
            $OS = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $ComputerName -ErrorAction Stop
        }

        # Return structured output for successful queries
        [pscustomobject]@{
            ComputerName = $ComputerName
            OSCaption    = $OS.Caption
            LastBoot     = $OS.LastBootUpTime
            Status       = 'Success'
            Error        = $null
        }
    }
    catch {
        # Return structured output for failed queries
        [pscustomobject]@{
            ComputerName = $ComputerName
            OSCaption    = $null
            LastBoot     = $null
            Status       = 'Failed'
            Error        = $_.Exception.Message
        }
    }
}

# --- Script Execution ---

# Initialize results array
$Results = @()

# Call 1: Local Host (No argument)
$Results += Get-SystemSnapshot

# Call 2: Remote Host (Intentionally bad name)
$Results += Get-SystemSnapshot -ComputerName 'NonExistentHost'

# Output results in a clean table format
$Results | Format-Table -AutoSize
# 1. Define the function with a default parameter value [cite: 373]
function Get-SystemSnapshot {
    param(
        [string]$ComputerName = $env:COMPUTERNAME
    )

    try {
        # 2. Use IF/ELSE to determine execution context 
        # This prevents local queries from being treated as remote connection attempts.
        if ($ComputerName -eq $env:COMPUTERNAME) {
            # Implementation: Retrieve CIM instance locally without -ComputerName 
        }
        else {
            # Implementation: Retrieve CIM instance using -ComputerName and ErrorAction Stop 
        }

        # 3. Return successful [pscustomobject] 
        # Ensure properties match: ComputerName, OSCaption, LastBoot, Status, and Error.
    }
    catch {
        # 4. Handle failure and return a failure object
        # Use $_.Exception.Message to capture the error.
    }
}

# 5. Call the function twice and pipe to Format-Table
# Call 1: Local (No arguments)
# Call 2: Remote (Intentionally bad host name)


# Chapter 5 Exercise: Orchestrated Remote Inventory (Skeleton)
# Practice the module and parallel orchestrator patterns.

# 1. Setup Environment [cite: 5.7, 5.8]
$Targets = @('System-1', 'System-2', 'System-3', 'Depot')
$Credential = Get-Credential
$ModulePath = (Resolve-Path ".\student_CapstoneTools.psm1").Path

# Staging paths (ensure these exist locally on Ops)
$SrcBinary = 'C:\Tools\Sysmon\Sysmon64.exe'
$SrcConfig = 'C:\Tools\Sysmon\sysmonconfig-export.xml'

# 2. Parallel Orchestrator Pattern [cite: 5.8]
$Jobs = foreach ($ComputerName in $Targets) {
    Start-Job -Name "Job_$ComputerName" `
              -ArgumentList $ModulePath, $ComputerName, $Credential, $SrcBinary, $SrcConfig `
              -ScriptBlock {
        param($Mod, $Comp, $Creds, $Bin, $Cfg)

        # A. Import required module inside the separate job context [cite: 5.6, 5.8]
        Import-Module -Name $Mod -Force

        # B. Execute Inventory [cite: 5.2]
        Get-RemoteTaskInfo -ComputerName $Comp -Credential $Creds

        # C. Execute Deployment [cite: 5.4]
        Deploy-RemoteSupportFiles -ComputerName $Comp -Credential $Creds -BinaryPath $Bin -ConfigPath $Cfg
    }
}

# 3. Job Lifecycle Management [cite: 5.8, 5.9]
Write-Host "Waiting for orchestration to complete..." -ForegroundColor Cyan
$null = $Jobs | Wait-Job
$Results = $Jobs | Receive-Job
$Jobs | Remove-Job

# 4. Final Reporting
$Results | Format-Table -AutoSize

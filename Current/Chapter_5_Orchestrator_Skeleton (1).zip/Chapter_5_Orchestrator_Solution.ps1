# Chapter 5 Exercise: Orchestrated Remote Inventory (Solution)
# Implements a full parallel workflow with module-based functions.

# --- 1. Orchestration Setup ---
$Targets = @('System-1', 'System-2', 'System-3', 'Depot')
$Credential = Get-Credential
$ModulePath = (Resolve-Path ".\student_CapstoneTools.psm1").Path

# Example source paths for staging [cite: 5.4]
$SrcBinary = 'C:\Tools\Sysmon\Sysmon64.exe'
$SrcConfig = 'C:\Tools\Sysmon\sysmonconfig-export.xml'

# --- 2. Dispatch Parallel Jobs [cite: 5.8] ---
$Jobs = foreach ($Target in $Targets) {
    Start-Job -Name "Orch_$Target" `
              -ArgumentList $ModulePath, $Target, $Credential, $SrcBinary, $SrcConfig `
              -ScriptBlock {
        param($M, $T, $C, $B, $Config)

        # Jobs run in a separate context; must import logic [cite: 5.6, 5.8]
        Import-Module -Name $M -Force

        # Gather info and deploy files in sequence per target [cite: 5.2, 5.4]
        $Inventory = Get-RemoteTaskInfo -ComputerName $T -Credential $C
        $Deployment = Deploy-RemoteSupportFiles -ComputerName $T -Credential $C -BinaryPath $B -ConfigPath $Config

        # Emit both result objects for collection [cite: 5.1]
        $Inventory
        $Deployment
    }
}

# --- 3. Collection and Cleanup [cite: 5.8, 5.9] ---
Write-Host "Processing targets System-1, System-2, System-3, and Depot in parallel..." -ForegroundColor Cyan

$null = $Jobs | Wait-Job
$Results = $Jobs | Receive-Job
$Jobs | Remove-Job

# --- 4. Report Generation ---
Write-Host "`n--- Global Orchestration Report ---" -ForegroundColor Yellow
$Results | Select-Object ComputerName, Function, Status, Error | Format-Table -AutoSize

# Detailed view of successful data
Write-Host "Successful Remote Data Summary:" -ForegroundColor Green
$Results | Where-Object Status -eq 'Success' | Select-Object ComputerName, Function, Data

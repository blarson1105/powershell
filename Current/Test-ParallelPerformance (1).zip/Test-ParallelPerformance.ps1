# Chapter 4 Exercise: Parallel Performance Auditor (Skeleton)
# Goals: Measure baseline, implement parallel jobs, and compare runtimes.

$Targets = @('System-1', 'System-2', 'System-3', 'Depot')
$ServiceToCheck = 'WinRM'

# --- Part 1: Sequential Baseline ---
# Use Measure-Command to time a standard foreach loop
$SequentialTime = Measure-Command {
    # Implementation: Loop through targets and run Invoke-Command sequentially
}

# --- Part 2: Parallel Implementation ---
# Use Measure-Command to time the job-based approach
$ParallelTime = Measure-Command {
    # 1. Start one job per target using the Canonical Course Pattern
    # Hint: Pass $ServiceToCheck into -ArgumentList
    $Jobs = foreach ($Target in $Targets) {
        # Start-Job implementation
    }

    # 2. Wait for all jobs to complete
    
    # 3. Receive results into a variable
    
    # 4. Remove jobs to clean the session
}

# --- Part 3: Reporting ---
# Output the timing comparison and the retrieved data
Write-Host "Sequential Run: $($SequentialTime.TotalSeconds) seconds"
Write-Host "Parallel Run:   $($ParallelTime.TotalSeconds) seconds"

# Display the received results table
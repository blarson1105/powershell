# Chapter 4 Exercise: Parallel Performance Auditor (Solution)
# Demonstrates timing, job lifecycle management, and argument passing.

$Targets = @('System-1', 'System-2', 'System-3', 'Depot')
$ServiceToCheck = 'WinRM'

# --- Part 1: Sequential Baseline ---
$SequentialTime = Measure-Command {
    foreach ($Target in $Targets) {
        Invoke-Command -ComputerName $Target -ScriptBlock {
            param($Svc)
            Get-Service -Name $Svc | Select-Object MachineName, Name, Status
        } -ArgumentList $ServiceToCheck
    }
}

# --- Part 2: Parallel Implementation ---
$Results = @()
$ParallelTime = Measure-Command {
    # 1. Start one job per target (Canonical Pattern)
    $Jobs = foreach ($Target in $Targets) {
        Start-Job -Name "Audit_$Target" -ArgumentList $Target, $ServiceToCheck -ScriptBlock {
            param($Computer, $Svc)
            # Jobs run in a separate context; return a clean object
            Invoke-Command -ComputerName $Computer -ScriptBlock {
                param($SvcName)
                $Service = Get-Service -Name $SvcName
                [pscustomobject]@{
                    ComputerName = $using:Computer
                    ServiceName  = $Service.Name
                    Status       = $Service.Status
                }
            } -ArgumentList $Svc
        }
    }

    # 2. Wait for completion
    $null = $Jobs | Wait-Job

    # 3. Receive results
    $global:Results = $Jobs | Receive-Job

    # 4. Cleanup
    $Jobs | Remove-Job
}

# --- Part 3: Reporting ---
Write-Host "`n--- Performance Audit Results ---" -ForegroundColor Cyan
Write-Host "Sequential Wall-Clock Time: $($SequentialTime.TotalSeconds) seconds"
Write-Host "Parallel Wall-Clock Time:   $($ParallelTime.TotalSeconds) seconds"

# Calculate improvement
$Delta = $SequentialTime.TotalSeconds - $ParallelTime.TotalSeconds
Write-Host "Time Saved:                 $Delta seconds" -ForegroundColor Green

Write-Host "`n--- Retrieved Data ---" -ForegroundColor Cyan
$global:Results | Format-Table -AutoSize
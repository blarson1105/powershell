# Chapter Exercise Files — 170A WOAC Advanced PowerShell

This package contains skeleton and solution files for the chapter exercises specified in the CVTE LMS course book.

## Source mapping

| File | Source section in the course book |
|---|---|
| `Ch1_Get-SystemSnapshot.ps1` | §1.X — Chapter 1 Exercise: Build a System Info Reporter |
| `Ch2_Test-Environment.ps1` | §2.7 — Chapter 2 Exercise |
| `Ch3_Test-RemoteConnectivity.ps1` | §3.8 — Chapter 3 Exercise: Remote Connectivity Validator |
| `Ch4_Test-ParallelPerformance.ps1` | §4.7 — Chapter 4 Exercise: Parallel Performance Auditor |
| `Ch5_RemoteOpsTools.psm1` | §5.2, §5.3, §5.4, §5.6 — Practice module functions and assembly |
| `Ch5_Run-RemoteOpsDryRun.ps1` | §5.11 — Chapter 5 Exercise: End-to-End Dry Run |

## Folder structure

- **Skeleton/** — student-facing files with numbered comments where students fill in code
- **Solution/** — instructor reference implementations matching the verbatim patterns shown in the course book

## Capstone vs practice files

The Chapter 5 files (`RemoteOpsTools.psm1`, `Run-RemoteOpsDryRun.ps1`) are **practice files**, not capstone deliverables. Per §5.10 and §5.11, the capstone deliverables are:
- `CapstoneTools.psm1` (different function names, different cmdlets in the script blocks)
- `Invoke-Capstone.ps1` (the capstone orchestrator)

The practice files exercise the same patterns; the capstone is a recombination, not a copy.

## Verification before student release

These files were syntactically balanced (braces and parens) but **not executed against the CVTE range**. Before releasing to students:

1. Run each Solution file end-to-end on the live range
2. Confirm the credential format expected by the domain-based environment (NetBIOS vs UPN per §3.4)
3. Confirm the Sysmon source paths in `Ch5_RemoteOpsTools.psm1` and `Ch5_Run-RemoteOpsDryRun.ps1` (the files default to `C:\Tools\Sysmon\` — adjust if your range stages files elsewhere)
4. Confirm `WinRM` is the appropriate service name for `Ch4_Test-ParallelPerformance.ps1` on the targets

## Naming conventions

Each filename has a `Ch#_` prefix so it's immediately obvious which chapter the file belongs to. This solves the alignment ambiguity that existed in the prior set of uploaded exercise files where Exercise_1 and Exercise_2 had no chapter label.

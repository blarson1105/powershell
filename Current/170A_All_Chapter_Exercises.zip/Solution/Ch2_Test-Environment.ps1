# ==============================================================================
# Chapter 2 Exercise: Test-Environment (Solution)
# File:    Test-Environment.ps1
# Source:  Course book section 2.7
# ==============================================================================


# 1. Discover the .NET type backing the version table.
$TableType = $PSVersionTable.GetType().FullName


# 2. Use static members (::) for immediate system data.
$Now  = [datetime]::Now
$User = [environment]::UserName


# 3. Use an instance method (.) on the captured $Now to perform date math.
#    The static-then-instance sequence is the pattern the capstone tests for.
$ReviewDate = $Now.AddDays(30)


# 4. Use the [math] static member to round a value.
$RoundedValue = [math]::Round(124.76)


# 5. Package as a [pscustomobject] for clean output.
[pscustomobject]@{
    NET_Type    = $TableType
    CurrentUser = $User
    ReviewDue   = $ReviewDate
    RoundedNum  = $RoundedValue
}

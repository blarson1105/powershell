# ==============================================================================
# Chapter 5 Practice Module (Solution)
# File:    RemoteOpsTools.psm1
# Purpose: Three reusable functions developed across sections 5.2-5.4,
#          packaged per the module-assembly pattern in section 5.6.
# Source:  Course book sections 5.1, 5.2, 5.3, 5.4, 5.6
#
# IMPORTANT: This is a PRACTICE module. It is NOT the capstone deliverable.
# The capstone deliverable is CapstoneTools.psm1 with different function names
# and different cmdlets in the script blocks. See section 5.10.
# ==============================================================================


# -----------------------------------------------------------------------------
# Function 1: Get-RemoteTaskInfo (section 5.2)
# Canonical Get-* skeleton from section 5.1, applied to scheduled tasks.
# -----------------------------------------------------------------------------
function Get-RemoteTaskInfo {
    param(
        [string]$ComputerName,
        [pscredential]$Credential
    )

    try {
        $Data = Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
            Get-ScheduledTask | Where-Object State -eq 'Ready' |
                Select-Object TaskName, State, TaskPath -First 10
        } -ErrorAction Stop

        [pscustomobject]@{
            ComputerName = $ComputerName
            Function     = 'Get-RemoteTaskInfo'
            Status       = 'Success'
            Data         = $Data
            Error        = $null
        }
    }
    catch {
        [pscustomobject]@{
            ComputerName = $ComputerName
            Function     = 'Get-RemoteTaskInfo'
            Status       = 'Failed'
            Data         = $null
            Error        = $_.Exception.Message
        }
    }
}


# -----------------------------------------------------------------------------
# Function 2: Get-RemoteEventSummary (section 5.3)
# Same skeleton as Function 1; the only changes are the function name,
# the Function field value, and the cmdlet inside the script block.
# -----------------------------------------------------------------------------
function Get-RemoteEventSummary {
    param(
        [string]$ComputerName,
        [pscredential]$Credential
    )

    try {
        $Data = Invoke-Command -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
            Get-WinEvent -LogName System -MaxEvents 25 |
                Where-Object LevelDisplayName -in 'Error', 'Warning' |
                Select-Object -First 10 TimeCreated, Id, ProviderName, LevelDisplayName, Message
        } -ErrorAction Stop

        [pscustomobject]@{
            ComputerName = $ComputerName
            Function     = 'Get-RemoteEventSummary'
            Status       = 'Success'
            Data         = $Data
            Error        = $null
        }
    }
    catch {
        [pscustomobject]@{
            ComputerName = $ComputerName
            Function     = 'Get-RemoteEventSummary'
            Status       = 'Failed'
            Data         = $null
            Error        = $_.Exception.Message
        }
    }
}


# -----------------------------------------------------------------------------
# Function 3: Deploy-RemoteSupportFiles (section 5.4)
# Different pattern from Get-*: persistent session, file copy, verification,
# explicit cleanup via finally.
# -----------------------------------------------------------------------------
function Deploy-RemoteSupportFiles {
    [CmdletBinding()]
    param(
        [string]$ComputerName,
        [pscredential]$Credential,
        [string]$BinaryPath,
        [string]$ConfigPath
    )

    $Session = $null

    try {
        if (-not (Test-Path -Path $BinaryPath)) {
            throw "BinaryPath not found: $BinaryPath"
        }

        if (-not (Test-Path -Path $ConfigPath)) {
            throw "ConfigPath not found: $ConfigPath"
        }

        $Session = New-PSSession -ComputerName $ComputerName -Credential $Credential -ErrorAction Stop

        Copy-Item -Path $BinaryPath -Destination 'C:\Windows\Temp\Sysmon64.exe' -ToSession $Session -Force -ErrorAction Stop
        Copy-Item -Path $ConfigPath -Destination 'C:\Windows\Temp\sysmonconfig-export.xml' -ToSession $Session -Force -ErrorAction Stop

        $Data = Invoke-Command -Session $Session -ScriptBlock {
            Get-Item 'C:\Windows\Temp\Sysmon64.exe', 'C:\Windows\Temp\sysmonconfig-export.xml' |
                Select-Object Name, Length, LastWriteTime
        } -ErrorAction Stop

        [pscustomobject]@{
            ComputerName = $ComputerName
            Function     = 'Deploy-RemoteSupportFiles'
            Status       = 'Success'
            Data         = $Data
            Error        = $null
        }
    }
    catch {
        [pscustomobject]@{
            ComputerName = $ComputerName
            Function     = 'Deploy-RemoteSupportFiles'
            Status       = 'Failed'
            Data         = $null
            Error        = $_.Exception.Message
        }
    }
    finally {
        if ($Session) { Remove-PSSession $Session }
    }
}


# -----------------------------------------------------------------------------
# Module export list (section 5.6)
# -----------------------------------------------------------------------------
Export-ModuleMember -Function Get-RemoteTaskInfo, Get-RemoteEventSummary, Deploy-RemoteSupportFiles

# ==============================================================================
# Chapter 5 Exercise: End-to-End Dry Run (Solution)
# File:    Run-RemoteOpsDryRun.ps1
# Source:  Course book section 5.11
# Goal:    Prove the full Chapter 5 workflow works end-to-end before
#          attempting the capstone build.
#
# REQUIRES: RemoteOpsTools.psm1 in the same directory as this script.
# ==============================================================================


# --- Setup ---------------------------------------------------------------
$Targets    = 'System-1', 'System-2', 'System-3', 'Depot'
$Credential = Get-Credential
$ModulePath = (Resolve-Path '.\RemoteOpsTools.psm1').Path


# --- Step 1: Import module and verify ------------------------------------
Import-Module $ModulePath -Force

$Loaded = Get-Command -Module RemoteOpsTools
Write-Host "Loaded $($Loaded.Count) function(s) from RemoteOpsTools:" -ForegroundColor Cyan
$Loaded | Format-Table Name, CommandType -AutoSize

if ($Loaded.Count -ne 3) {
    throw "Expected 3 functions in RemoteOpsTools, found $($Loaded.Count). Check Export-ModuleMember in the .psm1 file."
}


# --- Step 2: Sanity check one target sequentially ------------------------
Write-Host "`n--- Sanity check against System-1 ---" -ForegroundColor Cyan

$SanityTask  = Get-RemoteTaskInfo     -ComputerName 'System-1' -Credential $Credential
$SanityEvent = Get-RemoteEventSummary -ComputerName 'System-1' -Credential $Credential

$SanityTask, $SanityEvent | Format-Table ComputerName, Function, Status, Error -AutoSize

if ($SanityTask.Status -ne 'Success' -or $SanityEvent.Status -ne 'Success') {
    Write-Host "Sanity check failed. Investigate before running the parallel step." -ForegroundColor Red
    if ($SanityTask.Status -ne 'Success')  { Write-Host "  Get-RemoteTaskInfo: $($SanityTask.Error)" -ForegroundColor Red }
    if ($SanityEvent.Status -ne 'Success') { Write-Host "  Get-RemoteEventSummary: $($SanityEvent.Error)" -ForegroundColor Red }
    return
}


# --- Step 3: Run all three functions in parallel against all targets -----
Write-Host "`n--- Parallel run across all targets ---" -ForegroundColor Cyan

$Jobs = foreach ($Target in $Targets) {
    Start-Job -ArgumentList $Target, $Credential, $ModulePath -ScriptBlock {
        param($ComputerName, $Credential, $ModulePath)

        # Import the module INSIDE the job. Each job runs in its own runspace
        # and does not inherit the parent session's loaded modules.
        Import-Module $ModulePath -Force

        # Emit each result; the pipeline in the parent session collects them all.
        Get-RemoteTaskInfo     -ComputerName $ComputerName -Credential $Credential
        Get-RemoteEventSummary -ComputerName $ComputerName -Credential $Credential
        Deploy-RemoteSupportFiles `
            -ComputerName $ComputerName `
            -Credential   $Credential `
            -BinaryPath   'C:\Tools\Sysmon\Sysmon64.exe' `
            -ConfigPath   'C:\Tools\Sysmon\sysmonconfig-export.xml'
    }
}


# --- Step 4: Collect results ---------------------------------------------
$Results = $Jobs | Receive-Job -Wait -AutoRemoveJob


# --- Step 5: Verify and report -------------------------------------------
Write-Host "`n--- All results ---" -ForegroundColor Cyan
$Results | Format-Table ComputerName, Function, Status, Error -AutoSize

$Failed = $Results | Where-Object Status -eq 'Failed'
if ($Failed) {
    Write-Host "`n--- Failures ---" -ForegroundColor Yellow
    $Failed | Format-Table ComputerName, Function, Error -AutoSize -Wrap
} else {
    Write-Host "`nAll $($Results.Count) result objects returned Status='Success'." -ForegroundColor Green
}

# Sanity-check the result count: 4 targets x 3 functions = 12.
$Expected = $Targets.Count * 3
if ($Results.Count -ne $Expected) {
    Write-Host "`nWARNING: expected $Expected result objects, got $($Results.Count)." -ForegroundColor Yellow
    Write-Host "One or more functions did not emit a result. Check the parallel job output." -ForegroundColor Yellow
}


# --- Step 6: Cleanup -----------------------------------------------------
Get-PSSession | Remove-PSSession
Get-Job       | Remove-Job -Force

Write-Host "`nCleanup complete. Get-PSSession and Get-Job should both be empty." -ForegroundColor Cyan


# ==============================================================================
# Self-check before declaring this exercise complete (section 5.11):
#   (1) Script completed without throwing.
#   (2) Result table shows 12 rows with consistent property names.
#   (3) Get-PSSession and Get-Job are both empty.
#   (4) Re-run in the same console session: same behavior.
#   (5) Break one target (bad hostname): script still completes, the broken
#       target produces three Status='Failed' rows instead of throwing.
# ==============================================================================

# ==============================================================================
# Chapter 3 Exercise: Remote Connectivity Validator (Solution)
# File:    Test-RemoteConnectivity.ps1
# Source:  Course book section 3.8
# ==============================================================================


function Test-RemoteConnectivity {
    param(
        [string[]]$ComputerName = @('System-1', 'System-2', 'System-3', 'Depot'),
        [pscredential]$Credential = (Get-Credential)
    )

    foreach ($Target in $ComputerName) {

        $Session = $null

        try {
            # 1. Verify WinRM reachability. Suppress Test-WSMan's native output;
            #    we only care whether the call throws.
            $null = Test-WSMan -ComputerName $Target -ErrorAction Stop

            # 2. Open a persistent session for the identity check.
            $Session = New-PSSession -ComputerName $Target -Credential $Credential -ErrorAction Stop

            # 3. Capture the authenticated identity and the hostname the call
            #    actually reached.
            $Remote = Invoke-Command -Session $Session -ScriptBlock {
                [pscustomobject]@{
                    User = whoami
                    Host = hostname
                }
            } -ErrorAction Stop

            # 4. Success object.
            [pscustomobject]@{
                ComputerName     = $Target
                Reachable        = $true
                AuthenticatedAs  = $Remote.User
                Hostname         = $Remote.Host
                Error            = $null
            }
        }
        catch {
            # 5. Failure object - same shape as the success object.
            [pscustomobject]@{
                ComputerName     = $Target
                Reachable        = $false
                AuthenticatedAs  = $null
                Hostname         = $null
                Error            = $_.Exception.Message
            }
        }
        finally {
            # 6. Always close the session if one was opened.
            if ($Session) { Remove-PSSession $Session }
        }
    }
}


# --- Script Execution ----------------------------------------------------

$Results = Test-RemoteConnectivity
$Results | Format-Table -AutoSize

# ==============================================================================
# Chapter 1 Exercise: Build a System Info Reporter (Solution)
# File:    Get-SystemSnapshot.ps1
# Source:  Course book section 1.X (Chapter 1 Exercise)
# ==============================================================================


function Get-SystemSnapshot {
    param(
        [string]$ComputerName = $env:COMPUTERNAME
    )

    try {
        if ($ComputerName -eq $env:COMPUTERNAME) {
            # Local query: omit -ComputerName so the call stays local.
            $OS = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
        }
        else {
            # Remote query: target a specific host with terminating error handling.
            $OS = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $ComputerName -ErrorAction Stop
        }

        [pscustomobject]@{
            ComputerName = $ComputerName
            OSCaption    = $OS.Caption
            LastBoot     = $OS.LastBootUpTime
            Status       = 'Success'
            Error        = $null
        }
    }
    catch {
        [pscustomobject]@{
            ComputerName = $ComputerName
            OSCaption    = $null
            LastBoot     = $null
            Status       = 'Failed'
            Error        = $_.Exception.Message
        }
    }
}


# --- Script Execution -----------------------------------------------------

$Results = @()

# Call 1: Local Host (no argument)
$Results += Get-SystemSnapshot

# Call 2: Remote Host (intentionally bad name)
$Results += Get-SystemSnapshot -ComputerName 'NonExistentHost'

$Results | Format-Table -AutoSize

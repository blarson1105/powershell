# ==============================================================================
# Chapter 4 Exercise: Parallel Performance Auditor (Solution)
# File:    Test-ParallelPerformance.ps1
# Source:  Course book section 4.7
# ==============================================================================


$Targets        = @('System-1', 'System-2', 'System-3', 'Depot')
$ServiceToCheck = 'WinRM'


# --- Part 1: Sequential Baseline -----------------------------------------
$SequentialTime = Measure-Command {
    foreach ($Target in $Targets) {
        Invoke-Command -ComputerName $Target -ArgumentList $ServiceToCheck -ScriptBlock {
            param($Svc)
            Get-Service -Name $Svc | Select-Object MachineName, Name, Status
        }
    }
}


# --- Part 2: Parallel Implementation -------------------------------------
# $ParallelResults is declared at script scope so the Measure-Command block
# can populate it via $script: and the reporting section can read it.
$ParallelResults = $null

$ParallelTime = Measure-Command {

    # 1. One job per target. Both $Target and $ServiceToCheck are passed
    #    via -ArgumentList; the order matters and must match the param()
    #    declaration inside the script block.
    $Jobs = foreach ($Target in $Targets) {
        Start-Job -Name "Audit_$Target" -ArgumentList $Target, $ServiceToCheck -ScriptBlock {
            param($ComputerName, $Svc)
            Invoke-Command -ComputerName $ComputerName -ArgumentList $Svc -ScriptBlock {
                param($SvcName)
                $Service = Get-Service -Name $SvcName
                [pscustomobject]@{
                    ComputerName = $env:COMPUTERNAME
                    ServiceName  = $Service.Name
                    Status       = $Service.Status
                }
            }
        }
    }

    # 2. Wait for completion.
    $null = $Jobs | Wait-Job

    # 3. Receive results into the script-scope variable.
    $script:ParallelResults = $Jobs | Receive-Job

    # 4. Cleanup.
    $Jobs | Remove-Job
}


# --- Part 3: Reporting ---------------------------------------------------
Write-Host "`n--- Performance Audit Results ---" -ForegroundColor Cyan
Write-Host "Sequential Wall-Clock Time: $($SequentialTime.TotalSeconds) seconds"
Write-Host "Parallel Wall-Clock Time:   $($ParallelTime.TotalSeconds) seconds"

$Delta = $SequentialTime.TotalSeconds - $ParallelTime.TotalSeconds
Write-Host "Time Saved:                 $Delta seconds" -ForegroundColor Green

Write-Host "`n--- Retrieved Data ---" -ForegroundColor Cyan
$ParallelResults | Format-Table -AutoSize

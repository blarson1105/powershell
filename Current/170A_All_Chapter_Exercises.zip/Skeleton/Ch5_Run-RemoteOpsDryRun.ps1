# ==============================================================================
# Chapter 5 Exercise: End-to-End Dry Run (Skeleton)
# File:    Run-RemoteOpsDryRun.ps1
# Source:  Course book section 5.11
# Goal:    Prove the full Chapter 5 workflow works end-to-end before
#          attempting the capstone build.
#
# REQUIRES: RemoteOpsTools.psm1 in the same directory as this script.
# ==============================================================================


# --- Setup ---------------------------------------------------------------
$Targets    = 'System-1', 'System-2', 'System-3', 'Depot'
$Credential = Get-Credential
$ModulePath = (Resolve-Path '.\RemoteOpsTools.psm1').Path


# --- Step 1: Import module and verify ------------------------------------
# 1a. Import RemoteOpsTools.psm1 with -Force so changes since last import
#     are picked up. Use $ModulePath.

# 1b. Confirm all three functions are available by piping
#     Get-Command -Module RemoteOpsTools to a variable (e.g., $Loaded).
#     Then assert that $Loaded.Count -eq 3, or display $Loaded.

# 1c. (Optional but recommended) If any of the three are missing, throw
#     a clear error so the rest of the script does not run with a broken
#     module.


# --- Step 2: Sanity check one target sequentially ------------------------
# 2a. Run Get-RemoteTaskInfo against System-1 with $Credential.
#     Capture the result so you can inspect it.

# 2b. Run Get-RemoteEventSummary against System-1 with $Credential.
#     Capture the result.

# 2c. Confirm both have Status='Success'. If either is 'Failed', display
#     the Error property and stop. There is no point continuing to the
#     parallel run if a single-target sequential call already fails.

# 2d. Skip Deploy-RemoteSupportFiles for the sanity check. The deploy
#     function is exercised in Step 3 inside the parallel run.


# --- Step 3: Run all three functions in parallel against all targets -----
# Provided pattern: foreach + Start-Job. The argument-list ordering MUST
# match the param() declaration inside the script block. Mixing them up
# causes confusing 'access denied' errors.
$Jobs = foreach ($Target in $Targets) {
    Start-Job -ArgumentList $Target, $Credential, $ModulePath -ScriptBlock {
        param($ComputerName, $Credential, $ModulePath)

        # 3a. Import the module INSIDE the job script block.
        #     Each job runs in its own runspace and does not inherit
        #     the parent session's loaded modules. Forgetting this
        #     produces 'command not found' errors.

        # 3b. Call Get-RemoteTaskInfo, Get-RemoteEventSummary, and
        #     Deploy-RemoteSupportFiles against $ComputerName with
        #     $Credential. Emit each result so all three flow back.
        #
        #     For Deploy-RemoteSupportFiles, use these paths (adjust
        #     if your range stages files elsewhere):
        #       -BinaryPath 'C:\Tools\Sysmon\Sysmon64.exe'
        #       -ConfigPath 'C:\Tools\Sysmon\sysmonconfig-export.xml'
    }
}


# --- Step 4: Collect results ---------------------------------------------
# 4a. Use Receive-Job -Wait -AutoRemoveJob so the script blocks until
#     all jobs complete and removes them automatically.
$Results = # <implementation>


# --- Step 5: Verify and report -------------------------------------------
# 5a. Pipe $Results to Format-Table -AutoSize for a quick visual check.

# 5b. Pipe $Results | Where-Object Status -eq 'Failed' to confirm there
#     are no failures, OR to see exactly what failed and why.

# 5c. (Optional) Assert that $Results.Count -eq 12 (4 targets × 3 functions).
#     Anything other than 12 means one or more functions did not emit
#     a result.


# --- Step 6: Cleanup -----------------------------------------------------
# Even with -AutoRemoveJob, sessions inside Deploy-RemoteSupportFiles
# can persist if the function failed before its finally block executed.
# Clean up explicitly to leave a known-good session state.
Get-PSSession | Remove-PSSession
Get-Job       | Remove-Job -Force


# ==============================================================================
# Self-check before declaring this exercise complete (section 5.11):
#   (1) Does the script complete without throwing?
#   (2) Does the result table show 12 rows with consistent property names?
#   (3) Are Get-PSSession and Get-Job both empty after the script finishes?
#   (4) Re-run the script in the same console session - same behavior?
#   (5) Deliberately break one target (use a hostname that does not exist).
#       Does the script still complete, with a 'Failed' row instead of
#       a thrown error?
# All five must pass before moving to the capstone.
# ==============================================================================

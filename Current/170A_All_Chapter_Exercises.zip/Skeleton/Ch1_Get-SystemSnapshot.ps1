# ==============================================================================
# Chapter 1 Exercise: Build a System Info Reporter (Skeleton)
# File:    Get-SystemSnapshot.ps1
# Source:  Course book section 1.X (Chapter 1 Exercise)
#
# Goal:    Put together the skills from Chapter 1 into one short script.
#          This is the minimum viable version of a capstone function.
# ==============================================================================


function Get-SystemSnapshot {
    param(
        # 1. Default value of $env:COMPUTERNAME so a no-argument call queries locally
        [string]$ComputerName = $env:COMPUTERNAME
    )

    try {
        # 2. Decide local vs remote based on whether $ComputerName matches
        #    the local machine. This avoids treating local queries as remote
        #    connection attempts.
        if ($ComputerName -eq $env:COMPUTERNAME) {
            # 2a. Local query: Get-CimInstance Win32_OperatingSystem
            #     - Omit -ComputerName to keep the connection local
            #     - Use -ErrorAction Stop so failures are caught below
            $OS = # <implementation>
        }
        else {
            # 2b. Remote query: Get-CimInstance Win32_OperatingSystem
            #     - Use -ComputerName $ComputerName
            #     - Use -ErrorAction Stop
            $OS = # <implementation>
        }

        # 3. Return a SUCCESS [pscustomobject] with these EXACT properties:
        #    ComputerName, OSCaption, LastBoot, Status, Error
        #    - Status = 'Success'
        #    - Error  = $null
        #    - OSCaption from $OS.Caption
        #    - LastBoot from $OS.LastBootUpTime

    }
    catch {
        # 4. Return a FAILURE object with the SAME property names so success
        #    and failure rows have identical shape.
        #    - Status = 'Failed'
        #    - OSCaption = $null
        #    - LastBoot  = $null
        #    - Error     = $_.Exception.Message

    }
}


# --- Script Execution -----------------------------------------------------

# 5. Initialize a results array, call the function twice, and pipe to Format-Table:
#    Call 1: local (no argument)
#    Call 2: remote with an intentionally bad computer name
#
#    Both rows should display cleanly. The error message is captured in the
#    object, not thrown to the console.

$Results = @()

# Call 1: Local Host (no argument)
$Results += # <implementation>

# Call 2: Remote Host (intentionally bad name)
$Results += # <implementation>

# Pipe to Format-Table
$Results | Format-Table -AutoSize


# ==============================================================================
# Self-check before declaring this exercise complete:
#   - Both rows display cleanly in the Format-Table output.
#   - The bad-name row has Status='Failed' and a populated Error column.
#   - Pipe a result to Get-Member: the type is PSCustomObject and both
#     success and failure objects expose identical property names.
# ==============================================================================

# ==============================================================================
# Chapter 2 Exercise: Test-Environment (Skeleton)
# File:    Test-Environment.ps1
# Source:  Course book section 2.7
#
# Goal:    Audit the current execution environment by reaching for .NET
#          types where a cmdlet is not obvious, and return a clean
#          structured object.
# ==============================================================================


# 1. Discover the type of $PSVersionTable
#    Hint: every object exposes a .GetType() method, and the resulting
#    type object exposes a .FullName property.
$TableType = # <implementation>


# 2. Get current system info using STATIC members (the :: operator).
#    Hint: [datetime] has a static Now property, and [environment] has a
#    static UserName property.
$Now  = # <use [datetime]>
$User = # <use [environment]>


# 3. Calculate a review date using an INSTANCE method (the . operator).
#    Hint: capture the current date into a variable first (you already
#    have $Now from Step 2), then call AddDays on that variable.
#    The static-then-instance pattern is the one the capstone tests for.
$ReviewDate = # <use $Now and the AddDays method>


# 4. Use [math] to round 124.76 to the nearest whole integer.
#    Hint: [math] has a static Round method.
$RoundedValue = # <implementation>


# 5. Return all four findings in a single [pscustomobject].
[pscustomobject]@{
    NET_Type    = $TableType
    CurrentUser = $User
    ReviewDue   = $ReviewDate
    RoundedNum  = $RoundedValue
}


# ==============================================================================
# Self-check before declaring this exercise complete:
#   (1) Every variable holds a real value, not $null.
#   (2) The final [pscustomobject] returns one clean row when piped to
#       Format-Table.
#   (3) ReviewDue shows a real date 30 days from now, not today's date with
#       a string appended.
# ==============================================================================

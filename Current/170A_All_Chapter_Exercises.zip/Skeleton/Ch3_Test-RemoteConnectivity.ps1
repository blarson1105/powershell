# ==============================================================================
# Chapter 3 Exercise: Remote Connectivity Validator (Skeleton)
# File:    Test-RemoteConnectivity.ps1
# Source:  Course book section 3.8
#
# Goal:    Validate connectivity and authentication to a list of remote
#          targets before kicking off a larger script run. Failures must
#          be captured cleanly. The validator must never crash the
#          calling script.
# ==============================================================================


function Test-RemoteConnectivity {
    param(
        # Default to the four CVTE targets so the function can be tested
        # without arguments. Override by passing -ComputerName explicitly.
        [string[]]$ComputerName = @('System-1', 'System-2', 'System-3', 'Depot'),
        [pscredential]$Credential = (Get-Credential)
    )

    foreach ($Target in $ComputerName) {

        $Session = $null

        try {
            # 1. Test WinRM reachability
            #    Hint: Test-WSMan -ComputerName $Target -ErrorAction Stop
            #    Use $null = Test-WSMan ... to suppress its native output;
            #    you only care whether it throws.

            # 2. Open a PSSession to the target
            #    Hint: New-PSSession -ComputerName $Target -Credential $Credential
            #    Capture the result in $Session so the finally block can close it.
            $Session = # <implementation>

            # 3. Inside the session, run whoami and hostname
            #    Hint: Invoke-Command -Session $Session -ScriptBlock { ... }
            #    Capture the result in $Remote. The script block should
            #    return a [pscustomobject] with two properties: User and Host.
            $Remote = # <implementation>

            # 4. Return a SUCCESS [pscustomobject] with these EXACT properties:
            #    ComputerName, Reachable, AuthenticatedAs, Hostname, Error
            #    - Reachable        = $true
            #    - AuthenticatedAs  = $Remote.User
            #    - Hostname         = $Remote.Host
            #    - Error            = $null

        }
        catch {
            # 5. Return a FAILURE [pscustomobject] with the SAME property names.
            #    - Reachable        = $false
            #    - AuthenticatedAs  = $null
            #    - Hostname         = $null
            #    - Error            = $_.Exception.Message

        }
        finally {
            # 6. Close the session if one was opened, even on failure.
            #    Hint: if ($Session) { Remove-PSSession $Session }

        }
    }
}


# --- Script Execution ----------------------------------------------------

# Run the function and display results
$Results = Test-RemoteConnectivity
$Results | Format-Table -AutoSize


# ==============================================================================
# Self-check before declaring this exercise complete (section 3.8):
#   (1) Run with all four targets reachable. Returns four success rows?
#   (2) Run with one target name deliberately wrong. Returns three success
#       rows and one failure row, all with the same shape?
#   (3) After the function returns, run Get-PSSession. Is it empty?
# ==============================================================================

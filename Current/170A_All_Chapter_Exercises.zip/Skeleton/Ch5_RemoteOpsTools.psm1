# ==============================================================================
# Chapter 5 Practice Module (Skeleton)
# File:    RemoteOpsTools.psm1
# Purpose: Three reusable functions students build across sections 5.2-5.4,
#          packaged per the module-assembly pattern in section 5.6.
# Source:  Course book sections 5.1, 5.2, 5.3, 5.4, 5.6
#
# IMPORTANT: This is a PRACTICE module. It is NOT the capstone deliverable.
# The capstone deliverable is CapstoneTools.psm1 with different function names
# and different cmdlets in the script blocks. See section 5.10.
# ==============================================================================


# -----------------------------------------------------------------------------
# Function 1: Get-RemoteTaskInfo (section 5.2)
# Pattern source: section 5.1 canonical Get-* skeleton
# -----------------------------------------------------------------------------
function Get-RemoteTaskInfo {
    param(
        [string]$ComputerName,
        [pscredential]$Credential
    )

    try {
        # 1. Use Invoke-Command against $ComputerName with $Credential
        #    - Pass -ErrorAction Stop so failures are caught by the catch block
        #    - In the script block: query Get-ScheduledTask | Where-Object State -eq 'Ready'
        #    - Select TaskName, State, TaskPath -First 10
        #    - Assign the result to $Data
        $Data = # <implementation>

        # 2. Return a SUCCESS [pscustomobject] with these EXACT properties:
        #    ComputerName, Function, Status, Data, Error
        #    Status = 'Success', Error = $null, Function = 'Get-RemoteTaskInfo'

    }
    catch {
        # 3. Return a FAILURE [pscustomobject] with the SAME property names:
        #    ComputerName, Function, Status, Data, Error
        #    Status = 'Failed', Data = $null, Error = $_.Exception.Message

    }
}


# -----------------------------------------------------------------------------
# Function 2: Get-RemoteEventSummary (section 5.3)
# Pattern source: section 5.1 canonical Get-* skeleton
# Same skeleton as Function 1, only the script block changes.
# -----------------------------------------------------------------------------
function Get-RemoteEventSummary {
    param(
        [string]$ComputerName,
        [pscredential]$Credential
    )

    try {
        # 1. Use Invoke-Command against $ComputerName with $Credential
        #    - Pass -ErrorAction Stop
        #    - In the script block: Get-WinEvent -LogName System -MaxEvents 25
        #      then Where-Object LevelDisplayName -in 'Error', 'Warning'
        #      then Select-Object -First 10 TimeCreated, Id, ProviderName,
        #                                    LevelDisplayName, Message
        $Data = # <implementation>

        # 2. Return a SUCCESS object with the canonical 5-property shape
        #    Function = 'Get-RemoteEventSummary'

    }
    catch {
        # 3. Return a FAILURE object with the same 5-property shape

    }
}


# -----------------------------------------------------------------------------
# Function 3: Deploy-RemoteSupportFiles (section 5.4)
# Pattern source: section 5.4 deployment skeleton (different from Get-* pattern)
# Adds: persistent session, validation, file copy, verification, finally cleanup.
# -----------------------------------------------------------------------------
function Deploy-RemoteSupportFiles {
    [CmdletBinding()]
    param(
        [string]$ComputerName,
        [pscredential]$Credential,
        [string]$BinaryPath,
        [string]$ConfigPath
    )

    # Declare session variable BEFORE try so finally can reference it
    $Session = $null

    try {
        # 1. Validate BinaryPath exists locally; throw a clear message if it does not
        #    Hint: if (-not (Test-Path -Path $BinaryPath)) { throw "..." }

        # 2. Validate ConfigPath exists locally with the same pattern

        # 3. Open a persistent session to $ComputerName with $Credential
        #    - Use New-PSSession with -ErrorAction Stop
        #    - Assign to $Session
        $Session = # <implementation>

        # 4. Copy the binary to C:\Windows\Temp\Sysmon64.exe on the target
        #    - Use Copy-Item with -ToSession $Session, -Force, -ErrorAction Stop

        # 5. Copy the config to C:\Windows\Temp\sysmonconfig-export.xml on the target
        #    - Same Copy-Item pattern

        # 6. Verify both files arrived on the target
        #    - Use Invoke-Command -Session $Session
        #    - Inside the script block: Get-Item the two destination paths
        #    - Select Name, Length, LastWriteTime
        #    - Assign to $Data
        $Data = # <implementation>

        # 7. Return a SUCCESS object with the canonical 5-property shape
        #    Function = 'Deploy-RemoteSupportFiles'

    }
    catch {
        # 8. Return a FAILURE object with the canonical 5-property shape

    }
    finally {
        # 9. CRITICAL: clean up the session whether we succeeded or failed
        #    Hint: if ($Session) { Remove-PSSession $Session }

    }
}


# -----------------------------------------------------------------------------
# Module export list (section 5.6)
# Defines the public interface of the module. Only these three functions
# should be callable from outside.
# -----------------------------------------------------------------------------
Export-ModuleMember -Function Get-RemoteTaskInfo, Get-RemoteEventSummary, Deploy-RemoteSupportFiles

# ==============================================================================
# Chapter 4 Exercise: Parallel Performance Auditor (Skeleton)
# File:    Test-ParallelPerformance.ps1
# Source:  Course book section 4.7
#
# Goal:    Audit how long a status check against the four targets takes,
#          and confirm whether converting it to a parallel pattern actually
#          improves runtime. Build the auditor as a single script that runs
#          both versions and reports the difference.
# ==============================================================================


$Targets        = @('System-1', 'System-2', 'System-3', 'Depot')
$ServiceToCheck = 'WinRM'


# --- Part 1: Sequential Baseline -----------------------------------------
# Use Measure-Command to time a standard foreach loop that runs Invoke-Command
# against each target in sequence, querying $ServiceToCheck.
$SequentialTime = Measure-Command {
    # 1. foreach ($Target in $Targets) { Invoke-Command -ComputerName $Target ... }
    #    Inside the script block, use Get-Service against the WinRM service
    #    name and return a small object (MachineName, Name, Status).
    #    Hint: pass $ServiceToCheck via -ArgumentList and a param() block.

}


# --- Part 2: Parallel Implementation -------------------------------------
# Use Measure-Command to time the canonical course pattern from section 4.5:
# start one job per target, wait, receive, remove.
$ParallelResults = $null
$ParallelTime    = Measure-Command {
    # 1. Start one job per target using the canonical pattern.
    #    Hint: pass both $Target and $ServiceToCheck into -ArgumentList,
    #    and declare matching param() variables inside the script block.
    $Jobs = foreach ($Target in $Targets) {
        # Start-Job implementation
    }

    # 2. Wait for all jobs to complete.
    #    Hint: $null = $Jobs | Wait-Job

    # 3. Receive results into a script-scope variable. Use $script: scope so
    #    the value is reachable outside the Measure-Command block.
    #    $script:ParallelResults = $Jobs | Receive-Job

    # 4. Remove the jobs to clean the session.
    #    Hint: $Jobs | Remove-Job
}


# --- Part 3: Reporting ---------------------------------------------------
# Output the timing comparison and the retrieved data.
# Write-Host is acceptable here: timings are operator-facing diagnostic
# information, not data being passed forward in a pipeline.
Write-Host "Sequential Run: $($SequentialTime.TotalSeconds) seconds"
Write-Host "Parallel Run:   $($ParallelTime.TotalSeconds) seconds"

# Display the retrieved parallel data table
# $ParallelResults | Format-Table -AutoSize


# ==============================================================================
# Self-check before declaring this exercise complete (section 4.7):
#   (1) Both $SequentialTime and $ParallelTime are valid TimeSpan objects.
#   (2) The parallel run completes faster than the sequential run.
#   (3) The parallel run returns retrieved data, not just timing.
#   (4) Get-Job is empty after the script completes.
#   (5) Re-running in the same session produces consistent behavior.
# ==============================================================================

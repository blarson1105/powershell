# 1. Discover the .NET type backing the version table
$TableType = $PSVersionTable.GetType().FullName

# 2. Use static members (::) for immediate system data
$Now  = [datetime]::Now
$User = [environment]::UserName

# 3. Use an instance method (.) to perform date math
# We use parentheses because .AddDays() is a method, not a property.
$ReviewDate = $Now.AddDays(30)

# 4. Use the [math] static member to round a value
$RoundedValue = [math]::Round(124.76)

# 5. Package as a [pscustomobject] for clean output
[pscustomobject]@{
    NET_Type     = $TableType
    CurrentUser  = $User
    ReviewDue    = $ReviewDate
    RoundedNum   = $RoundedValue
    CurrentHost  = [environment]::MachineName # Another useful static member
}
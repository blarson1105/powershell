# 1. Discover the type of $PSVersionTable
# Hint: Use .GetType().FullName
$TableType = # <Implementation goes here>

# 2. Get current system info using static members (::)
$Now      = # <Use [datetime]>
$User     = # <Use [environment]>

# 3. Calculate a review date using an instance method (.)
# Hint: Call a method on the $Now object to add 30 days
$ReviewDate = # <Implementation goes here>

# 4. Use [math] to round 124.76
$RoundedValue = # <Implementation goes here>

# 5. Return the results as a structured object
[pscustomobject]@{
    NET_Type    = $TableType
    CurrentUser = $User
    ReviewDue   = $ReviewDate
    RoundedNum  = $RoundedValue
}
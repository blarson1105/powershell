<#
.SYNOPSIS
    Chapter 3 Exercise — Remote Connectivity Validator

.DESCRIPTION
    This exercise reinforces: WinRM connectivity testing, remote
    execution context, language mode awareness, and structured
    per-host error handling.

    Complete each TODO section. The target list and output structure
    are provided — you build the logic.

.NOTES
    Course : 170A WOAC — Advanced PowerShell Scripting
    Chapter: 3 — Remote Execution, Security, and Operational Constraints
    Tags   : K3, K4, K6, K8
#>

# ──────────────────────────────────────────────────────────────────────
#  SETUP — do not modify
# ──────────────────────────────────────────────────────────────────────

$Targets = @('System-1', 'System-2', 'System-3', 'Depot')
$Results = @()

# ──────────────────────────────────────────────────────────────────────
#  MAIN LOOP
# ──────────────────────────────────────────────────────────────────────

foreach ($Target in $Targets) {

    # Initialize per-host tracking variables
    $WinRMReachable = $false
    $RemoteUser     = $null
    $LanguageMode   = $null
    $ErrorMsg       = $null

    # ── PHASE 1: Test WinRM ──────────────────────────────────────────

    # TODO 1: Use Test-WSMan against $Target inside a try/catch.
    #         If it succeeds, set $WinRMReachable = $true.
    #         If it fails, capture the exception message in $ErrorMsg
    #         and skip to the result object (use 'continue' or
    #         structure your code so Phase 2 only runs on success).


    # ── PHASE 2: Query remote context ────────────────────────────────

    # TODO 2: If WinRM is reachable, use Invoke-Command to run a
    #         script block on $Target that returns TWO things:
    #           - whoami
    #           - $ExecutionContext.SessionState.LanguageMode
    #
    #         Store the results in $RemoteUser and $LanguageMode.
    #
    #         Hint: You can return a hashtable or two separate calls.
    #         Wrap this in its own try/catch so a failure here does
    #         not crash the loop.


    # ── BUILD RESULT ─────────────────────────────────────────────────

    # TODO 3: Build a [pscustomobject] and add it to $Results.
    #         Properties:
    #   ComputerName   = $Target
    #   WinRMReachable = $WinRMReachable
    #   RemoteUser     = $RemoteUser
    #   LanguageMode   = $LanguageMode
    #   Error          = $ErrorMsg

}

# ──────────────────────────────────────────────────────────────────────
#  DISPLAY RESULTS
# ──────────────────────────────────────────────────────────────────────

# TODO 4: Pipe $Results to Format-Table to display all columns.

# $Results | Format-Table -AutoSize


<#
  ┌────────────────────────────────────────────────────────────────────┐
  │  EXPECTED OUTPUT (example — your values will vary)                │
  ├──────────────┬───────────────┬──────────────┬──────────────┬──────┤
  │ ComputerName │ WinRMReachable│ RemoteUser   │ LanguageMode │Error │
  ├──────────────┼───────────────┼──────────────┼──────────────┼──────┤
  │ System-1     │ True          │ domain\user  │ FullLanguage │      │
  │ System-2     │ True          │ domain\user  │ FullLanguage │      │
  │ System-3     │ True          │ domain\user  │ FullLanguage │      │
  │ Depot        │ True          │ domain\user  │ FullLanguage │      │
  └──────────────┴───────────────┴──────────────┴──────────────┴──────┘
#>


# ──────────────────────────────────────────────────────────────────────
#  REFLECTION
# ──────────────────────────────────────────────────────────────────────

<#
  Q1: If one target returned ConstrainedLanguage, what would that
      change about what your scripts can do on that host?

  Q2: If System-3 fails the WinRM test but the others succeed,
      what should your script do — stop entirely, or keep going?
      Why?

  Q3: The whoami output tells you the remote execution identity.
      Why might that matter for the capstone deployment function?
#>

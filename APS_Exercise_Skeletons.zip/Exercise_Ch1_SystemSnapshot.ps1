<#
.SYNOPSIS
    Chapter 1 Exercise — Build a System Info Reporter

.DESCRIPTION
    This exercise reinforces: functions, parameters, PSCustomObject,
    try/catch error handling, and pipeline output.

    Complete each TODO section. Do not change the function name or
    parameter names — they are used by the success criteria check
    at the bottom of this file.

.NOTES
    Course : 170A WOAC — Advanced PowerShell Scripting
    Chapter: 1 — PowerShell Scripting Foundations Review
    Tags   : K1, K2
#>

# ──────────────────────────────────────────────────────────────────────
#  FUNCTION: Get-SystemSnapshot
# ──────────────────────────────────────────────────────────────────────

function Get-SystemSnapshot {
    <#
    .SYNOPSIS
        Retrieves basic OS information from a local or remote system.

    .EXAMPLE
        Get-SystemSnapshot
        Get-SystemSnapshot -ComputerName 'System-1'
    #>

    param(
        # TODO 1: Define a [string] parameter called $ComputerName.
        #         Give it a default value of $env:COMPUTERNAME so the
        #         function works locally when no argument is provided.

    )

    # TODO 2: Open a try block.

        # TODO 3: Use Get-CimInstance to query Win32_OperatingSystem.
        #         Store the result in a variable called $OS.
        #
        #         Hint: You need -ErrorAction Stop so failures enter
        #         the catch block instead of printing red text.

        # TODO 4: Return a [pscustomobject] with these properties:
        #   ComputerName  = $ComputerName
        #   OSCaption     = <the Caption property from $OS>
        #   LastBoot      = <the LastBootUpTime property from $OS>
        #   Status        = 'Success'
        #   Error         = $null

    # TODO 5: Add a catch block that returns a failure object.
    #         Use the SAME property names as TODO 4, but set:
    #   Status = 'Failed'
    #   Error  = $_.Exception.Message
    #   (set OSCaption and LastBoot to $null)
}


# ──────────────────────────────────────────────────────────────────────
#  TEST YOUR WORK
# ──────────────────────────────────────────────────────────────────────

# Once your function is complete, uncomment the lines below and run
# the script. Both calls should produce clean table output — one
# success row and one failure row.

# $Results = @()
# $Results += Get-SystemSnapshot                              # local — should succeed
# $Results += Get-SystemSnapshot -ComputerName 'YOURFAKEPC'   # bad name — should fail gracefully
# $Results | Format-Table -AutoSize

<#
  ┌──────────────────────────────────────────────────────────────────┐
  │  EXPECTED OUTPUT (example)                                      │
  ├────────────┬────────────────────────────┬────────────┬──────────┤
  │ ComputerName│ OSCaption                 │ Status     │ Error    │
  ├────────────┼────────────────────────────┼────────────┼──────────┤
  │ OPS        │ Microsoft Windows 10 ...  │ Success    │          │
  │ YOURFAKEPC │                            │ Failed     │ WinRM ..│
  └────────────┴────────────────────────────┴────────────┴──────────┘
#>

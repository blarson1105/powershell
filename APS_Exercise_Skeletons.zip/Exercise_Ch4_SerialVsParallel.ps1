<#
.SYNOPSIS
    Chapter 4 Exercise — Serial vs. Parallel Comparison

.DESCRIPTION
    This exercise reinforces: Measure-Command, Start-Job, Receive-Job,
    and understanding parallel execution overhead.

    You will run the SAME work serially and in parallel, measure both,
    and explain the difference.

.NOTES
    Course : 170A WOAC — Advanced PowerShell Scripting
    Chapter: 4 — Performance and Parallel Execution
    Tags   : K5
#>

# ──────────────────────────────────────────────────────────────────────
#  SETUP — do not modify
# ──────────────────────────────────────────────────────────────────────

$Targets = @('System-1', 'System-2', 'System-3', 'Depot')

# This script block simulates a 2-second remote task.
# In a real scenario this would be a query or deployment action.
$WorkBlock = {
    Start-Sleep -Seconds 2
    hostname
}

# ──────────────────────────────────────────────────────────────────────
#  PART 1: SERIAL EXECUTION
# ──────────────────────────────────────────────────────────────────────

# TODO 1: Wrap a foreach loop in Measure-Command.
#         Inside the loop, use Invoke-Command to run $WorkBlock
#         against each $Target one at a time.
#         Store the Measure-Command result in $SerialTime.

# $SerialTime = Measure-Command {
#     foreach ($Target in $Targets) {
#         # TODO: Invoke-Command here
#     }
# }


# ──────────────────────────────────────────────────────────────────────
#  PART 2: PARALLEL EXECUTION
# ──────────────────────────────────────────────────────────────────────

# TODO 2: Wrap a Start-Job fan-out in Measure-Command.
#         Start one job per target. Each job runs $WorkBlock.
#         Collect results with Receive-Job -Wait -AutoRemoveJob.
#         Store the Measure-Command result in $ParallelTime.
#
#         Hint: You need -ArgumentList to pass $Target into the job.
#         The script block inside Start-Job needs a param() to
#         receive it.

# $ParallelTime = Measure-Command {
#     $Jobs = foreach ($Target in $Targets) {
#         # TODO: Start-Job here
#     }
#     # TODO: Receive-Job here
# }


# ──────────────────────────────────────────────────────────────────────
#  PART 3: COMPARE RESULTS
# ──────────────────────────────────────────────────────────────────────

# TODO 3: Display both elapsed times and calculate the speedup.
#         Uncomment and complete:

# [pscustomobject]@{
#     SerialSeconds   = [math]::Round($SerialTime.TotalSeconds, 2)
#     ParallelSeconds = [math]::Round($ParallelTime.TotalSeconds, 2)
#     SpeedupFactor   = [math]::Round($SerialTime.TotalSeconds / $ParallelTime.TotalSeconds, 2)
# }


<#
  ┌────────────────────────────────────────────────────────────────────┐
  │  EXPECTED OUTPUT (approximate — your times will vary)             │
  ├───────────────┬─────────────────┬─────────────────────────────────┤
  │ SerialSeconds │ ParallelSeconds │ SpeedupFactor                   │
  ├───────────────┼─────────────────┼─────────────────────────────────┤
  │ 8.12          │ 2.85            │ 2.85                            │
  └───────────────┴─────────────────┴─────────────────────────────────┘

  Serial should be ~8 seconds (4 targets × 2 seconds each).
  Parallel should be ~2–4 seconds (all 4 run concurrently, plus overhead).
#>


# ──────────────────────────────────────────────────────────────────────
#  REFLECTION
# ──────────────────────────────────────────────────────────────────────

<#
  Q1: Why didn't the parallel version finish in exactly 2 seconds?
      What contributes to the extra time?

  Q2: If one of the four targets was unreachable and timed out after
      30 seconds, how would that affect serial vs. parallel total time?

  Q3: In the parallel version, do the jobs share variables with
      your parent session? What happens if you try to use $Targets
      inside a job without passing it as an argument?
#>

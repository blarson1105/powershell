<#
.SYNOPSIS
    Chapter 2 Exercise — .NET Type Explorer

.DESCRIPTION
    This exercise reinforces: .NET type discovery, static vs instance
    members, Get-Member, and building PSCustomObjects with .NET data.

    Complete each TODO section. Each step is independent — you can
    test as you go.

.NOTES
    Course : 170A WOAC — Advanced PowerShell Scripting
    Chapter: 2 — .NET for PowerShell Practitioners
    Tags   : K1
#>

# ──────────────────────────────────────────────────────────────────────
#  STEP 1: Instance method discovery
# ──────────────────────────────────────────────────────────────────────

# TODO 1a: Store the result of Get-Date in a variable called $Now.

# TODO 1b: Pipe $Now to Get-Member. Find a method that returns the
#           day of the week. (Hint: look at the method names.)

# TODO 1c: Call that method on $Now and store the result in $DayOfWeek.
#           Display it.


# ──────────────────────────────────────────────────────────────────────
#  STEP 2: Static method — path operations
# ──────────────────────────────────────────────────────────────────────

# TODO 2a: Use the static method [System.IO.Path]::GetTempPath()
#           to get the system temp directory. Store it in $TempDir.

# TODO 2b: Use [System.IO.Path]::Combine() to join $TempDir with
#           the filename 'test_output.csv'. Store in $TempFile.
#           Display $TempFile.


# ──────────────────────────────────────────────────────────────────────
#  STEP 3: Static method — DNS lookup
# ──────────────────────────────────────────────────────────────────────

# TODO 3a: Use [System.Net.Dns]::GetHostName() to get the hostname.
#           Store the result in $DnsHostName.

# TODO 3b: Compare $DnsHostName to $env:COMPUTERNAME.
#           Are they the same? Display both values and your answer.


# ──────────────────────────────────────────────────────────────────────
#  STEP 4: Build a summary object
# ──────────────────────────────────────────────────────────────────────

# TODO 4: Create a [pscustomobject] with these properties:
#   TimeStamp   = (use [datetime]::Now — this is a static member)
#   MachineName = (use [environment]::MachineName — static member)
#   TempPath    = $TempDir from Step 2
#   DayOfWeek   = $DayOfWeek from Step 1
#
# Display the object.


# ──────────────────────────────────────────────────────────────────────
#  REFLECTION
# ──────────────────────────────────────────────────────────────────────

<#
  Answer these before moving on:

  Q1: In Step 1, was .DayOfWeek an instance method or a property?
      How can you tell from Get-Member output?

  Q2: In Step 2, [System.IO.Path]::Combine() uses :: syntax.
      Is that a static member or an instance member?

  Q3: Could you call [datetime]::Now.DayOfWeek in a single
      expression? Why or why not?
#>

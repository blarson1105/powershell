<#
.SYNOPSIS
    Chapter 5 Exercise — End-to-End Dry Run

.DESCRIPTION
    This is a pre-capstone integration check. Complete this exercise
    before Day 5 to confirm your module, functions, and orchestrator
    pattern are working.

    This script does NOT replace your capstone artifacts. It is a
    structured test harness to validate them.

.NOTES
    Course : 170A WOAC — Advanced PowerShell Scripting
    Chapter: 5 — Applied Remote Scripting Workshop
    Tags   : K8, K9, S1, S2, S3, S4
#>

# ──────────────────────────────────────────────────────────────────────
#  SETUP — update the module path if yours differs
# ──────────────────────────────────────────────────────────────────────

$ModulePath  = '.\student_CapstoneTools.psm1'
$Targets     = @('System-1', 'System-2', 'System-3', 'Depot')
$BinaryPath  = 'C:\Tools\Sysmon\Sysmon64.exe'
$ConfigPath  = 'C:\Tools\Sysmon\sysmonconfig-export.xml'

# ──────────────────────────────────────────────────────────────────────
#  STEP 1: Import and verify module
# ──────────────────────────────────────────────────────────────────────

# TODO 1a: Import your module using Import-Module with -Force.

# TODO 1b: Run Get-Command -Module student_CapstoneTools and confirm
#           all three functions appear:
#             - Get-RemoteProcessInventory
#             - Get-RemoteServiceInventory
#             - Install-SysmonRemote
#
#           If any are missing, stop here and fix your .psm1 file.


# ──────────────────────────────────────────────────────────────────────
#  STEP 2: Get credentials
# ──────────────────────────────────────────────────────────────────────

# TODO 2: Prompt for credentials and store them.
#         You will reuse this variable for every function call.

# $Credential = Get-Credential


# ──────────────────────────────────────────────────────────────────────
#  STEP 3: Single-target test — Process query
# ──────────────────────────────────────────────────────────────────────

# TODO 3: Call Get-RemoteProcessInventory against ONE target.
#         Inspect the result. Confirm it has these properties:
#           ComputerName, Function, Status, Data, Error
#
#         Hint: Pipe the result to Get-Member to verify.

# $TestProcess = Get-RemoteProcessInventory -ComputerName 'System-1' -Credential $Credential
# $TestProcess
# $TestProcess | Get-Member


# ──────────────────────────────────────────────────────────────────────
#  STEP 4: Single-target test — Service query
# ──────────────────────────────────────────────────────────────────────

# TODO 4: Same as Step 3, but for Get-RemoteServiceInventory.
#         Confirm identical output structure.

# $TestService = Get-RemoteServiceInventory -ComputerName 'System-1' -Credential $Credential
# $TestService


# ──────────────────────────────────────────────────────────────────────
#  STEP 5: Single-target test — Sysmon deployment
# ──────────────────────────────────────────────────────────────────────

# TODO 5a: Call Install-SysmonRemote against ONE target.
#          Confirm the result shows Status = 'Success'.

# $TestDeploy = Install-SysmonRemote -ComputerName 'System-1' -Credential $Credential -BinaryPath $BinaryPath -ConfigPath $ConfigPath
# $TestDeploy

# TODO 5b: Verify the install by querying the Sysmon service remotely.
#          Uncomment and run:

# Invoke-Command -ComputerName 'System-1' -Credential $Credential -ScriptBlock {
#     Get-Service Sysmon*
# }


# ──────────────────────────────────────────────────────────────────────
#  STEP 6: Parallel execution — all targets
# ──────────────────────────────────────────────────────────────────────

# TODO 6: Use the orchestrator pattern from Section 5.8 to run
#         Get-RemoteProcessInventory against ALL FOUR targets
#         in parallel using Start-Job.
#
#         Remember:
#           - Resolve the module path first
#           - Pass $ComputerName, $Credential, and $ModulePath
#             into each job via -ArgumentList
#           - Import-Module inside the job
#           - Collect with Receive-Job -Wait -AutoRemoveJob

# $ResolvedPath = (Resolve-Path $ModulePath).Path
#
# $Jobs = foreach ($Target in $Targets) {
#     Start-Job -ArgumentList $Target, $Credential, $ResolvedPath -ScriptBlock {
#         param($ComputerName, $Credential, $ModulePath)
#         # TODO: Import module and call function here
#     }
# }
#
# $AllResults = $Jobs | Receive-Job -Wait -AutoRemoveJob
# $AllResults | Format-Table -AutoSize


# ──────────────────────────────────────────────────────────────────────
#  STEP 7: Cleanup
# ──────────────────────────────────────────────────────────────────────

# TODO 7: Remove any lingering sessions and jobs.
#         Uncomment and run:

# Get-PSSession | Remove-PSSession
# Get-Job | Remove-Job -Force


# ──────────────────────────────────────────────────────────────────────
#  READINESS CHECKLIST
# ──────────────────────────────────────────────────────────────────────

<#
  Before Day 5, confirm each item:

  [ ] Module imports without error
  [ ] All three functions are visible via Get-Command
  [ ] Get-RemoteProcessInventory returns structured output (single target)
  [ ] Get-RemoteServiceInventory returns structured output (single target)
  [ ] Install-SysmonRemote deploys Sysmon successfully (single target)
  [ ] Sysmon service is verifiable on the remote host
  [ ] Parallel execution works against all four targets
  [ ] Per-host failures are captured — not thrown
  [ ] Sessions and jobs are cleaned up after testing
#>

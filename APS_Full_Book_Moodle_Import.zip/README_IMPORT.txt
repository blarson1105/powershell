Advanced PowerShell Scripting Moodle Book Import Package

Naming:
- chapterN_00.html = main chapter
- chapterN_XX_sub.html = subchapters

Environment baseline used throughout the book:
- Ops = student workstation
- System-1, System-2, System-3, Depot = remote targets

Styling:
- Segoe UI / Arial body
- dark code blocks
- blue accent headings
- student-facing callouts

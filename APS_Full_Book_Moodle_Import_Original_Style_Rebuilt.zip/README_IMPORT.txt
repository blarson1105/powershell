Advanced PowerShell Scripting Moodle Book Import Package
Rebuilt to more closely match the original styling scheme:
- original color palette
- richer callout boxes
- token-colored PowerShell code blocks
- inline code badge styling

<#
.SYNOPSIS
    Invoke-Capstone - Reference orchestrator for the 170A WOAC Advanced PowerShell capstone.

.DESCRIPTION
    Imports the CapstoneTools module and dispatches remote diagnostic work in parallel
    across a list of target computers. Collects process and service information, then
    optionally deploys Sysmon to each target. Error handling is per-target: a failure
    on one target does not halt execution against other targets.

    Parallel execution uses ForEach-Object -Parallel (PowerShell 7+). Each runspace
    imports the module independently, creates its own session objects, and runs work
    under try/catch with session cleanup in finally blocks.

.PARAMETER ComputerName
    One or more target computer names or IP addresses.

.PARAMETER Credential
    A PSCredential object with administrative rights on all targets.

.PARAMETER ModulePath
    Absolute path to CapstoneTools.psm1.

.PARAMETER DeploySysmon
    Switch that enables Sysmon deployment alongside the query work.

.PARAMETER SysmonBinaryPath
    Local path to Sysmon64.exe. Required when -DeploySysmon is specified.

.PARAMETER SysmonConfigPath
    Local path to the Sysmon configuration XML file. Required when -DeploySysmon is specified.

.PARAMETER ThrottleLimit
    Maximum number of parallel runspaces. Default: 5.

.EXAMPLE
    $cred = Get-Credential
    .\Invoke-Capstone.ps1 -ComputerName 'System-1','System-2','System-3' `
                          -Credential $cred `
                          -ModulePath 'C:\Capstone\CapstoneTools.psm1'

.EXAMPLE
    $cred = Get-Credential
    .\Invoke-Capstone.ps1 -ComputerName 'System-1','System-2','System-3' `
                          -Credential $cred `
                          -ModulePath 'C:\Capstone\CapstoneTools.psm1' `
                          -DeploySysmon `
                          -SysmonBinaryPath 'C:\Tools\Sysmon64.exe' `
                          -SysmonConfigPath 'C:\Tools\sysmonconfig.xml'

.NOTES
    Reference orchestrator for 170A-WOAC-APS-CAP-SCOPE-001 v1.0.
    Requires PowerShell 7 or later.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string[]]$ComputerName,

    [Parameter(Mandatory)]
    [System.Management.Automation.PSCredential]$Credential,

    [Parameter(Mandatory)]
    [string]$ModulePath,

    [switch]$DeploySysmon,

    [string]$SysmonBinaryPath,

    [string]$SysmonConfigPath,

    [int]$ThrottleLimit = 5
)

# Pre-flight validation. Fail before dispatching any work.
if (-not (Test-Path $ModulePath)) {
    throw "Module not found: $ModulePath"
}

if ($DeploySysmon) {
    if (-not $SysmonBinaryPath -or -not $SysmonConfigPath) {
        throw "-DeploySysmon requires both -SysmonBinaryPath and -SysmonConfigPath."
    }
    if (-not (Test-Path $SysmonBinaryPath)) {
        throw "Sysmon binary not found: $SysmonBinaryPath"
    }
    if (-not (Test-Path $SysmonConfigPath)) {
        throw "Sysmon config not found: $SysmonConfigPath"
    }
}

Write-Verbose "Dispatching work across $($ComputerName.Count) targets at throttle $ThrottleLimit."

# ForEach-Object -Parallel: each element of $ComputerName runs the scriptblock concurrently.
# $using: reaches outside-scope variables into the runspace. Anything not in $using: is invisible
# to the parallel block — this is the rule students most often miss.
$results = $ComputerName | ForEach-Object -ThrottleLimit $ThrottleLimit -Parallel {
    $target       = $_
    $cred         = $using:Credential
    $modulePath   = $using:ModulePath
    $doDeploy     = $using:DeploySysmon
    $sysmonBinary = $using:SysmonBinaryPath
    $sysmonConfig = $using:SysmonConfigPath

    $targetResult = [PSCustomObject]@{
        ComputerName    = $target
        Status          = 'Unknown'
        ProcessCount    = $null
        ServiceCount    = $null
        SysmonDeployed  = $null
        SysmonState     = $null
        Error           = $null
        Timestamp       = Get-Date
    }

    try {
        # Module must be imported inside the runspace. Runspaces do not inherit the parent
        # session state. Import outside this block will not be visible here.
        Import-Module $modulePath -Force -ErrorAction Stop

        # S1 / R1: gather info from the remote system. Two calls, two CIM classes.
        $processes = Get-RemoteProcessInfo -ComputerName $target -Credential $cred
        $services  = Get-RemoteServiceInfo -ComputerName $target -Credential $cred

        $targetResult.ProcessCount = @($processes).Count
        $targetResult.ServiceCount = @($services).Count

        # S3 / R3: optional deploy. When present, this is where the deploy function runs.
        if ($doDeploy) {
            $deployResult = Install-SysmonRemote -ComputerName $target `
                                                 -Credential $cred `
                                                 -SysmonBinaryPath $sysmonBinary `
                                                 -SysmonConfigPath $sysmonConfig
            $targetResult.SysmonDeployed = ($deployResult.Status -eq 'Success')
            $targetResult.SysmonState    = $deployResult.ServiceState
            if ($deployResult.Status -ne 'Success') {
                # Deploy failure does not fail the whole target — query work may have succeeded.
                $targetResult.Error = $deployResult.Message
            }
        }

        $targetResult.Status = 'Success'
    }
    catch {
        # S4 / R4: per-target error handling. Failure here does not crash other runspaces
        # because each runspace has its own try/catch.
        $targetResult.Status = 'Failed'
        $targetResult.Error  = $_.Exception.Message
    }

    # Emit the result object. ForEach-Object -Parallel streams emissions back to the caller.
    $targetResult
}

# S4 / R4: distinguish successful vs. failed targets in output. Instructor-visible summary.
$successful = @($results | Where-Object { $_.Status -eq 'Success' })
$failed     = @($results | Where-Object { $_.Status -eq 'Failed'  })

Write-Host ""
Write-Host ("Capstone run complete. {0} succeeded, {1} failed." -f $successful.Count, $failed.Count) -ForegroundColor Cyan
Write-Host ""

if ($successful.Count -gt 0) {
    Write-Host "Successful targets:" -ForegroundColor Green
    $successful | Format-Table ComputerName, ProcessCount, ServiceCount, SysmonDeployed, SysmonState -AutoSize
}

if ($failed.Count -gt 0) {
    Write-Host "Failed targets:" -ForegroundColor Yellow
    $failed | Format-Table ComputerName, Error -AutoSize -Wrap
}

# Return the full result set to the pipeline for downstream consumption.
return $results

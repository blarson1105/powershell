# Capstone Reference Implementation — Companion Notes

**Document Type:** Instructor reference notes
**Related Contract:** `170A-WOAC-APS-CAP-SCOPE-001 v1.0`
**Version:** 1.0 (Draft — Pending Range Validation)
**Effective Date:** 2026-04-18

---

## 🔖 Purpose of This Document

This companion document explains the decisions embedded in `CapstoneTools.psm1` and `Invoke-Capstone.ps1`. It is **instructor-facing only** and is not distributed to students. Its job is to:

1. Trace each implementation choice to a specific CTSSB skill and rubric item
2. Document known failure modes students will hit
3. Provide validation commands for range testing
4. Distinguish the reference ceiling from the minimum passing floor

---

## 📋 Rubric-to-Code Traceability

| Rubric Item | CTSSB Skill | Where It Lives | How To Verify |
|---|---|---|---|
| R1 | S1 Gather info from multiple systems | `Get-RemoteProcessInfo` + `Get-RemoteServiceInfo` in `CapstoneTools.psm1` | Run each function standalone against a remote host; verify `PSCustomObject` output with expected fields |
| R2 | S2 Run jobs in parallel | `ForEach-Object -Parallel -ThrottleLimit` in `Invoke-Capstone.ps1` | Observe concurrent runspaces via timestamps on output objects or via `Get-Process pwsh` during run |
| R3 | S3 Deploy an application remotely | `Install-SysmonRemote` in `CapstoneTools.psm1` | After run, `Get-Service -Name Sysmon64` on target returns `Running` |
| R4 | S4 Integrate debugging / error handling | `try/catch/finally` in all three module functions and in orchestrator's parallel block | Induce a failure (offline target, bad credential) — script completes, per-target error is captured, sessions are cleaned up |

---

## 🎯 Design Decisions — Why This Code Looks The Way It Does

### Decision A: CimSession for queries, PSSession for deploy

**Choice:** `Get-RemoteProcessInfo` and `Get-RemoteServiceInfo` use `New-CimSession`; `Install-SysmonRemote` uses `New-PSSession`.

**Rationale:** CIM sessions are the purpose-built transport for CIM queries. PSSession is required for file transfer (`Copy-Item -ToSession`) and command invocation, which CIM sessions do not support. Each tool is used for what it was designed for.

**Trade-off accepted:** Students see two session types in one script. This is more complexity than a PSSession-only design, but it reflects operational reality and is pedagogically honest about the distinction between CIM and PSRemoting.

### Decision B: Negotiate authentication via `New-CimSessionOption -Protocol WSMan`

**Choice:** CIM sessions are created with an explicit WSMan session option.

**Rationale:** The range environment is a workgroup — no domain, no Kerberos. `Get-CimInstance -ComputerName` defaults to Kerberos/Negotiate and fails in workgroups. Explicit `New-CimSession` with Negotiate/NTLM via WSMan works. This is documented in the instructor memory notes as a known behavior.

**What students will get wrong:** They will try `Get-CimInstance -ComputerName $c -Credential $cred` directly, which fails in workgroups. The error message is not obvious. Teaching moment: CIM session explicit configuration is required outside a domain.

### Decision C: `Start-Process -Wait -PassThru` for Sysmon installation

**Choice:** The Sysmon installer runs via `Start-Process` with `-Wait` and `-PassThru` to capture the exit code.

**Rationale:** `Invoke-Command { & $sysmon -accepteula -i $cfg }` can succeed-with-errors because the exit code is not always captured cleanly by the invocation operator. `Start-Process -PassThru` returns a process object with `.ExitCode` which is the authoritative success signal.

**What students will get wrong:** They will invoke Sysmon without checking the exit code and claim success when the installer actually failed silently. Reference models the correct check.

### Decision D: `ForEach-Object -Parallel` over `Start-Job`

**Choice:** Parallel execution uses `ForEach-Object -Parallel`.

**Rationale:** Runspace-based, faster, pipeline-native, cleaner scope handling with `$using:`. Modern idiom for PowerShell 7. The range is on PowerShell 7, so the classical `Start-Job` pattern's "works on 5.1" advantage does not apply here.

**What students will get wrong:**
- Referencing outside-scope variables without `$using:` — the variable will be `$null` inside the runspace. Students will spend 15 minutes debugging this the first time.
- Assuming `Import-Module` in the parent scope carries into the runspace. It does not. Reference models the correct pattern: import inside the runspace.
- Forgetting `-ThrottleLimit`. Default is 5, which is fine for the range, but students should know the parameter exists.

### Decision E: Per-target structured result object

**Choice:** Each target returns a `PSCustomObject` with `Status`, `ProcessCount`, `ServiceCount`, `SysmonDeployed`, `SysmonState`, `Error`, `Timestamp`.

**Rationale:** R4 requires that output differentiate successful vs. failed targets. A structured object does this unambiguously — the orchestrator can `Where-Object { $_.Status -eq 'Failed' }` for aggregation, and instructors can grade from a single field.

**Alternative rejected:** Returning raw query data and letting the caller figure out what succeeded. That puts the error-handling burden on the consumer of the script, which is the opposite of what R4 asks for.

### Decision F: `finally` block for session cleanup

**Choice:** Every function uses `try/catch/finally` with session cleanup in `finally`.

**Rationale:** Sessions leak if not cleaned up. Students commonly forget this, which causes WinRM resource exhaustion on both client and server over a course week. `finally` guarantees cleanup even when the `try` block throws.

**What students will get wrong:** They will clean up sessions only in the `try` block, not `finally`. On any error, sessions leak. Reference models the correct placement.

---

## ⚠️ Known Failure Points (What Will Go Wrong First)

Ordered by how early in student debugging they appear:

| # | Failure | Symptom | Fix |
|---|---|---|---|
| 1 | CIM auth fails in workgroup | `The WinRM client cannot process the request because the server name cannot be resolved` or authentication error | Use explicit `New-CimSession` with `New-CimSessionOption -Protocol WSMan` and `-Credential` |
| 2 | `$cred` is `$null` inside parallel block | Credential parameter empty, auth fails on every target | Use `$using:Credential` inside the parallel scriptblock |
| 3 | `Import-Module` outside parallel block has no effect | `The term 'Get-RemoteProcessInfo' is not recognized` inside the runspace | `Import-Module` must be called inside the parallel scriptblock |
| 4 | PSSession leaked on error | Eventually WinRM quota exceeded; later runs fail to create sessions | Cleanup in `finally`, not `try` |
| 5 | Sysmon exit code not checked | Deploy reports "success" but service is not running | Capture `.ExitCode` from `Start-Process -PassThru`, check for 0 |
| 6 | `Get-Service` state check uses wrong property | Returns `Stopped` even after successful install | Wait a moment after install for service to transition to Running; or query `Win32_Service.State` via CIM |
| 7 | `LocalAccountTokenFilterPolicy` not set on target | PSSession creation fails with access denied despite correct credentials | Registry fix already noted in range change request — verify present before class |

---

## 🧪 Range Validation Procedure

These commands are the validation suite to run against the range before locking the reference.

**Prerequisites:**
- VTA range access
- `LocalAccountTokenFilterPolicy=1` DWORD set on all targets
- PSRemoting enabled on targets; TrustedHosts set to `System-1,System-2,System-3,Depot` on Ops
- Sysmon64.exe and sysmonconfig.xml staged locally on Ops

**Phase 1: Module Functions Standalone**

```powershell
$cred = Get-Credential
Import-Module .\CapstoneTools.psm1 -Force

# Expected: PSCustomObjects, non-zero count, clean output
Get-RemoteProcessInfo -ComputerName System-1 -Credential $cred | Measure-Object
Get-RemoteServiceInfo -ComputerName System-1 -Credential $cred | Measure-Object

# Expected: Status=Success, ServiceState=Running
Install-SysmonRemote -ComputerName System-1 -Credential $cred `
    -SysmonBinaryPath 'C:\Tools\Sysmon64.exe' `
    -SysmonConfigPath 'C:\Tools\sysmonconfig.xml'
```

**Phase 2: Orchestrator Without Deploy**

```powershell
$cred = Get-Credential
$targets = 'System-1','System-2','System-3'

.\Invoke-Capstone.ps1 -ComputerName $targets `
                      -Credential $cred `
                      -ModulePath 'C:\Capstone\CapstoneTools.psm1' `
                      -Verbose
```

**Expected:** All three targets return `Status=Success`, `ProcessCount` and `ServiceCount` populated, no `Error`, no terminal exceptions.

**Phase 3: Orchestrator With Deploy**

```powershell
.\Invoke-Capstone.ps1 -ComputerName $targets `
                      -Credential $cred `
                      -ModulePath 'C:\Capstone\CapstoneTools.psm1' `
                      -DeploySysmon `
                      -SysmonBinaryPath 'C:\Tools\Sysmon64.exe' `
                      -SysmonConfigPath 'C:\Tools\sysmonconfig.xml'
```

**Expected:** All targets report `SysmonDeployed=True` and `SysmonState=Running`. Verify independently:

```powershell
foreach ($t in $targets) {
    Invoke-Command -ComputerName $t -Credential $cred -ScriptBlock {
        Get-Service -Name Sysmon64
    }
}
```

**Phase 4: Induced Failure**

Add a non-existent hostname to the target list and re-run Phase 2:

```powershell
.\Invoke-Capstone.ps1 -ComputerName 'System-1','NonExistent-99','System-3' `
                      -Credential $cred `
                      -ModulePath 'C:\Capstone\CapstoneTools.psm1'
```

**Expected:** `System-1` and `System-3` succeed. `NonExistent-99` returns `Status=Failed` with an `Error` message. Script does not crash. Final summary shows "2 succeeded, 1 failed."

**Phase 5: Concurrency Verification**

Compare timing. Expected: parallel run is materially faster than serial.

```powershell
Measure-Command {
    .\Invoke-Capstone.ps1 -ComputerName $targets -Credential $cred -ModulePath 'C:\Capstone\CapstoneTools.psm1' -ThrottleLimit 3
}

Measure-Command {
    .\Invoke-Capstone.ps1 -ComputerName $targets -Credential $cred -ModulePath 'C:\Capstone\CapstoneTools.psm1' -ThrottleLimit 1
}
```

The `-ThrottleLimit 1` run serializes the work. Parallel run should be noticeably faster.

---

## 🏁 Reference Ceiling vs. Minimum Passing Floor

The reference is intentionally polished beyond what the rubric requires. Do not grade student submissions against the reference's aesthetics.

| Aspect | Reference (ceiling) | Minimum to pass rubric (floor) |
|---|---|---|
| Comment-based help on functions | Full `.SYNOPSIS`, `.DESCRIPTION`, `.PARAMETER`, `.EXAMPLE`, `.OUTPUTS` | Not required |
| Parameter validation | `[Parameter(Mandatory)]` with types | Functional parameters, type coercion acceptable |
| Session cleanup in `finally` | Yes, explicit | Yes — required by R4 "does not crash" |
| Error message quality | Contextual (includes target name) | Captured error, content not graded |
| Output object structure | Named fields, stable schema | Distinguishes success vs. failure — required by R4 |
| Sysmon installation exit-code checking | Yes, explicit | Service state verification is sufficient |
| Throttle parameter | Exposed, defaulted | Not required — any parallel mechanism works |
| Owner resolution in process info | Yes, with fallback for system processes | Not required by R1; presence of basic fields sufficient |

**Rubric grading principle:** A student submission that meets R1–R4 passes, regardless of how much simpler it looks than the reference.

---

## 🔬 Threat Hunting / Forensics Notes

*These notes exist to reinforce the operational relevance of what the code does. They are instructor talking points, not grading criteria.*

**`Get-RemoteProcessInfo`** is the foundation of live-response triage:
- `CommandLine` + `ParentProcessId` enables parent-child process chain analysis (MITRE T1057 Process Discovery, T1036 Masquerading)
- `ExecutablePath` outside `Program Files` or `System32` is a classic masquerading indicator
- Combined with `UserName`, you can identify unexpected SYSTEM-owned user processes (injection indicator)

**`Get-RemoteServiceInfo`** is persistence hunting:
- `StartName` reveals service account; services running as SYSTEM with executable paths in user-writable directories are persistence red flags (MITRE T1543.003 Windows Service)
- `PathName` unquoted with spaces is the classic unquoted-service-path privilege escalation vector
- `StartMode=Auto` + unusual `PathName` = persistence candidate

**`Install-SysmonRemote`** has real operational value:
- Sysmon deployment is the core of the SwiftOnSecurity/MTS/Olaf Hartong detection stack
- This function models the first step of "harden a host for visibility" — a real CTI/IR workflow
- The session-based deploy pattern is how actual deployment automation works

These angles can be integrated into student instruction but are not part of the rubric.

---

## 📝 Open Items Before Lock

1. **Range validation.** Run all five phases of the validation procedure above. Document any deviations.
2. **Sysmon config selection.** Decide which sysmonconfig.xml ships with the course (SwiftOnSecurity? MTS? Custom?). Reference uses whatever path is passed in; course materials need to commit.
3. **Service name verification.** Post-install service may be `Sysmon` or `Sysmon64` depending on installer variant. Reference checks both. Verify which installs on the range.
4. **Throttle tuning.** `-ThrottleLimit 5` is a reasonable default, but optimal value depends on how much the range can handle. Document observed behavior during validation.
5. **Parsons sign-off.** Both contracts and this reference require Parsons approval before formal release.

---

## 🔗 Related Documents

- `170A-WOAC-APS-CAP-SCOPE-001 v1.0` — Capstone Assessment Scope Contract (controlling authority)
- `170A-WOAC-APS-WRE-SCOPE-001 v1.0` — Written Assessment Scope Contract (companion)
- `CapstoneTools.psm1` — the module
- `Invoke-Capstone.ps1` — the orchestrator
- 170A CTSSB Output, 16 February 2024 — ultimate source authority

---

*End of Document — Capstone Reference Companion Notes v1.0*

Moodle Book Import Instructions

This zip is formatted for Moodle Book -> Import chapter.

Structure:
- One main chapter HTML file
- Multiple subchapter HTML files with filenames ending in _sub.html

Per Moodle documentation:
- Create a zip file of HTML files and optional multimedia files.
- If you wish to upload subchapters, add "_sub" to the end of HTML file or folder names.
- In Moodle Book, use Import chapter and choose each HTML file as one chapter.

Recommended import choice:
- Each HTML file represents one chapter

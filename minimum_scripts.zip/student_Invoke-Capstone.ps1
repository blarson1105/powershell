# Invoke-Capstone.ps1
# 170A WOAC Capstone - student submission

param(
    [string[]]$ComputerName,
    [pscredential]$Credential,
    [string]$ModulePath,
    [switch]$DeploySysmon,
    [string]$SysmonBinary,
    [string]$SysmonConfig
)

$results = $ComputerName | ForEach-Object -Parallel {
    $target = $_
    $cred   = $using:Credential
    $mod    = $using:ModulePath
    $deploy = $using:DeploySysmon
    $bin    = $using:SysmonBinary
    $cfg    = $using:SysmonConfig

    try {
        Import-Module $mod -Force

        $procs = Get-RemoteProcessInfo -ComputerName $target -Credential $cred
        $svcs  = Get-RemoteServiceInfo -ComputerName $target -Credential $cred

        $sysmonResult = $null
        if ($deploy) {
            $sysmonResult = Install-SysmonRemote -ComputerName $target -Credential $cred -BinaryPath $bin -ConfigPath $cfg
        }

        [PSCustomObject]@{
            ComputerName = $target
            Status       = 'Success'
            ProcessCount = @($procs).Count
            ServiceCount = @($svcs).Count
            SysmonState  = $sysmonResult.SysmonState
            Error        = $null
        }
    }
    catch {
        [PSCustomObject]@{
            ComputerName = $target
            Status       = 'Failed'
            ProcessCount = 0
            ServiceCount = 0
            SysmonState  = $null
            Error        = $_.Exception.Message
        }
    }
} -ThrottleLimit 5

Write-Host ""
Write-Host "Results:"
$results | Format-Table -AutoSize

$passed = ($results | Where-Object Status -eq 'Success').Count
$failed = ($results | Where-Object Status -eq 'Failed').Count
Write-Host "$passed succeeded, $failed failed"

return $results

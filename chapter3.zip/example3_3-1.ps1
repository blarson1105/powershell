# =============================================================================
# example3_3-1.ps1
# Chapter 3.3 - PowerShell Language Modes
# 170A WOAC Advanced PowerShell
# =============================================================================
# INSTRUCTOR DEMO GUIDE
# This script demonstrates the four PowerShell language modes and what each
# restricts. It also shows how to check the current mode and how ConstrainedLanguage
# is enforced via the __PSLockDownPolicy environment variable.
#
# !! IMPORTANT BOOK CORRECTION !!
# The course book states "Use Set-ExecutionPolicy to configure the default
# language mode." THIS IS INCORRECT.
#   - Set-ExecutionPolicy controls SCRIPT EXECUTION POLICY (whether .ps1 files
#     can run at all: Restricted, RemoteSigned, Unrestricted, etc.)
#   - Language Mode is controlled by:
#       $ExecutionContext.SessionState.LanguageMode  (check)
#       $env:__PSLockDownPolicy = 4                 (enforce ConstrainedLanguage system-wide)
#       WDAC / AppLocker policies                   (enterprise enforcement)
#   These are completely separate subsystems. A session can have ExecutionPolicy
#   set to Unrestricted but still be in ConstrainedLanguage mode.
#
# DEMO FLOW (suggested ~20 min):
#   Part 1 (~5 min)  - Run SECTION A in normal session; show FullLanguage
#   Part 2 (~8 min)  - Run SECTION B to set ConstrainedLanguage; show what breaks
#   Part 3 (~7 min)  - Discuss SECTION C (the __PSLockDownPolicy mechanism)
#
# CYBER RELEVANCE:
#   T1059.001 - Command and Scripting Interpreter: PowerShell
#     Attackers use FullLanguage mode to run .NET reflection, download cradles,
#     and invoke in-memory payloads. ConstrainedLanguage blocks most of these.
#   T1562.001 - Impair Defenses: Disable or Modify Tools
#     Adversaries with sufficient access may clear __PSLockDownPolicy or force
#     FullLanguage mode to escape a locked-down environment.
# =============================================================================

# =============================================================================
# SECTION A - Check and display the current language mode
# =============================================================================
Write-Host "`n--- SECTION A: Check Current Language Mode ---" -ForegroundColor Cyan

$currentMode = $ExecutionContext.SessionState.LanguageMode
Write-Host "  Current language mode: $currentMode" -ForegroundColor Green

Write-Host "`n  Testing capabilities available in $currentMode mode:"

# Test 1: .NET class access (blocked in ConstrainedLanguage)
Write-Host "`n  Test 1: .NET class instantiation [System.Collections.Generic.List]"
try {
    $list = [System.Collections.Generic.List[string]]::new()
    $list.Add("item1")
    Write-Host "    [ALLOWED] .NET class access works. Count: $($list.Count)" -ForegroundColor Green
}
catch {
    Write-Host "    [BLOCKED] .NET class access denied: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: Add-Type (blocked in ConstrainedLanguage)
Write-Host "`n  Test 2: Add-Type (compiling inline C# code)"
try {
    Add-Type -TypeDefinition @"
        public class TestClass {
            public string Hello() { return "Hello from C#"; }
        }
"@ -ErrorAction Stop
    $obj = New-Object TestClass
    Write-Host "    [ALLOWED] Add-Type works: $($obj.Hello())" -ForegroundColor Green
}
catch {
    Write-Host "    [BLOCKED] Add-Type denied: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Basic cmdlets (allowed in all modes except NoLanguage)
Write-Host "`n  Test 3: Basic cmdlet (Get-Process)"
try {
    $proc = Get-Process -Id $PID -ErrorAction Stop
    Write-Host "    [ALLOWED] Get-Process works: $($proc.Name) (PID $($proc.Id))" -ForegroundColor Green
}
catch {
    Write-Host "    [BLOCKED] Get-Process denied: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Script block with variable assignment (blocked in RestrictedLanguage)
Write-Host "`n  Test 4: Variable assignment in a script block"
try {
    $testBlock = { $x = 42; return $x }
    $result = & $testBlock
    Write-Host "    [ALLOWED] Script block with variable works: $result" -ForegroundColor Green
}
catch {
    Write-Host "    [BLOCKED] Script block denied: $($_.Exception.Message)" -ForegroundColor Red
}

# =============================================================================
# SECTION B - Demonstrate ConstrainedLanguage in a child session
# =============================================================================
# NOTE: We use a child PowerShell process with __PSLockDownPolicy=4 rather than
# modifying the current session's language mode directly.
# Setting $ExecutionContext.SessionState.LanguageMode in a FullLanguage session
# will work for the current session but is NOT how production enforcement works.
# __PSLockDownPolicy is how Windows Defender Application Control (WDAC) and
# AppLocker enforce it system-wide.

Write-Host "`n--- SECTION B: ConstrainedLanguage in a child process ---" -ForegroundColor Cyan
Write-Host "  (Spawning a child pwsh process with __PSLockDownPolicy=4)" -ForegroundColor DarkCyan

$constrainedTest = @'
$env:__PSLockDownPolicy = 4

Write-Host "  Child session language mode: $($ExecutionContext.SessionState.LanguageMode)"

Write-Host "`n  Re-running the same four tests in ConstrainedLanguage:`n"

# Test 1: .NET class access
Write-Host "  Test 1: .NET class instantiation"
try {
    $list = [System.Collections.Generic.List[string]]::new()
    Write-Host "    [ALLOWED] .NET class access works"
} catch {
    Write-Host "    [BLOCKED] $($_.Exception.Message)"
}

# Test 2: Add-Type
Write-Host "`n  Test 2: Add-Type"
try {
    Add-Type -TypeDefinition "public class T2 { public string M() { return `"hi`"; } }" -ErrorAction Stop
    Write-Host "    [ALLOWED] Add-Type works"
} catch {
    Write-Host "    [BLOCKED] $($_.Exception.Message)"
}

# Test 3: Basic cmdlet
Write-Host "`n  Test 3: Basic cmdlet (Get-Process)"
try {
    $proc = Get-Process -Id $PID -ErrorAction Stop
    Write-Host "    [ALLOWED] Get-Process works: $($proc.Name)"
} catch {
    Write-Host "    [BLOCKED] $($_.Exception.Message)"
}

# Test 4: Script block with variable
Write-Host "`n  Test 4: Variable assignment in script block"
try {
    $testBlock = { $x = 42; return $x }
    $result = & $testBlock
    Write-Host "    [ALLOWED] Script block works: $result"
} catch {
    Write-Host "    [BLOCKED] $($_.Exception.Message)"
}
'@

# Run the constrained test in a child process so we don't lock THIS session
$constrainedTest | pwsh -NonInteractive -Command -

# =============================================================================
# SECTION C - Instructor discussion: How language mode is enforced in production
# =============================================================================
Write-Host "`n--- SECTION C: How Language Mode is Enforced (Discussion) ---" -ForegroundColor Magenta
Write-Host @"

  METHOD 1 - Environment Variable (demo/testing only):
    `$env:__PSLockDownPolicy = 4   # Enables ConstrainedLanguage for the session
    `$env:__PSLockDownPolicy = 0   # Disables (back to FullLanguage)
    NOTE: This is process-scoped. A new pwsh.exe process inherits it if set in
    the parent's environment, but does not persist across reboots by itself.

  METHOD 2 - WDAC / AppLocker (production):
    When a WDAC or AppLocker policy is active and a script/module is NOT in an
    allowed path, PowerShell AUTOMATICALLY drops to ConstrainedLanguage mode.
    The user cannot override this - it is enforced by the kernel policy.

  METHOD 3 - Session configuration (JEA endpoints):
    New-PSSessionConfigurationFile -LanguageMode RestrictedLanguage
    This locks a specific remoting endpoint to a language mode regardless of
    what the connecting user tries.

  WHAT Set-ExecutionPolicy ACTUALLY DOES (BOOK CORRECTION):
    Set-ExecutionPolicy controls whether .ps1 SCRIPTS CAN RUN AT ALL.
      Restricted    = No scripts (interactive only)
      RemoteSigned  = Local scripts OK; downloaded scripts need signature
      Unrestricted  = All scripts run (with a warning for downloaded ones)
    It does NOT control .NET access, Add-Type, or any language mode feature.
    You can have ExecutionPolicy=Unrestricted AND LanguageMode=ConstrainedLanguage
    at the same time - they are completely independent settings.

  CYBER ANGLE:
    T1059.001: Most PowerShell-based malware (Empire, Cobalt Strike stagers,
    download cradles) requires FullLanguage mode to function. They use Add-Type,
    .NET reflection, or [System.Net.WebClient] - all blocked by ConstrainedLanguage.
    Checking the language mode on a compromised system tells you how hardened it was.

    T1562.001: A post-exploitation step sometimes seen is:
      `$env:__PSLockDownPolicy = 0  # Escape ConstrainedLanguage
    This only works if the attacker has not triggered WDAC enforcement.
    If WDAC is active, clearing the env var has no effect.

"@

Write-Host "--- Current session summary ---" -ForegroundColor Cyan
Write-Host "  Language Mode    : $($ExecutionContext.SessionState.LanguageMode)"
Write-Host "  Execution Policy : $(Get-ExecutionPolicy)"
Write-Host "  __PSLockDownPolicy env var: $(if ($env:__PSLockDownPolicy) { $env:__PSLockDownPolicy } else { '(not set)' })"

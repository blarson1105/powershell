# =============================================================================
# example3_2-1.ps1
# Chapter 3.2 - The Double-Hop Problem
# 170A WOAC Advanced PowerShell
# =============================================================================
# INSTRUCTOR DEMO GUIDE
# This script demonstrates the double-hop problem and its workaround using
# explicit credential passing via New-PSSession.
#
# ENVIRONMENT NOTES (VTA range):
#   - Range is a WORKGROUP (no domain / no Kerberos)
#   - Kerberos is the default for WinRM but FAILS in workgroup environments
#   - New-PSSession with explicit -Credential forces NTLM, which works
#   - This mirrors the double-hop failure pattern: the default auth silently
#     fails when trying to chain to a second hop
#
# DEMO FLOW (suggested ~20 min):
#   Part 1 (~5 min)  - Explain the double-hop concept (whiteboard/diagram)
#   Part 2 (~8 min)  - Run SECTION A; observe the auth failure
#   Part 3 (~7 min)  - Run SECTION B; observe the successful workaround
#
# CYBER RELEVANCE: T1550.003 - Use Alternate Authentication Material (Pass the Ticket)
#   The same Kerberos delegation chain that enables double-hop is abused by
#   adversaries using stolen tickets for lateral movement. The restriction
#   exists as a defense - weakening it (CredSSP) re-opens that attack surface.
# =============================================================================

# --- CONFIGURATION -----------------------------------------------------------
# Modify these values to match the range environment before the demo.
$hop1 = "System-1"    # First remote machine (the intermediary)
$hop2 = "System-2"    # Second remote machine (the final target)

# =============================================================================
# SECTION A - The Failure: Default WinRM behavior (Kerberos / no explicit cred)
# =============================================================================
# In a domain environment this would fail at the second hop.
# In the VTA workgroup this fails at the FIRST hop because Kerberos has no DC.
# The error message looks like an access denied or WinRM connectivity error -
# NOT a "double-hop error" - which is exactly what makes this hard to diagnose.

Write-Host "`n--- SECTION A: Attempting connection without explicit credentials ---" -ForegroundColor Yellow
Write-Host "    (This is expected to fail in the workgroup VTA range)" -ForegroundColor DarkYellow

try {
    # Attempt 1: Get-CimInstance with -ComputerName defaults to Kerberos
    # This will fail in the workgroup - there is no domain controller to issue tickets
    $os = Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $hop1 -ErrorAction Stop
    Write-Host "    Connected to $hop1 - OS: $($os.Caption)" -ForegroundColor Green

    # Attempt 2: From hop1, try to reach hop2 (the actual double-hop)
    # In a domain this would succeed for hop1 but fail here at hop2
    $session = New-PSSession -ComputerName $hop1 -ErrorAction Stop
    $result = Invoke-Command -Session $session -ScriptBlock {
        # This second connection FROM hop1 TO hop2 is where Kerberos tickets
        # cannot be forwarded - the double-hop failure
        Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $using:hop2 -ErrorAction Stop
    }
    Write-Host "    Connected to $hop2 via $hop1 - OS: $($result.Caption)" -ForegroundColor Green
    Remove-PSSession $session
}
catch {
    Write-Host "`n    [EXPECTED FAILURE] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    This is the double-hop problem (or workgroup Kerberos failure)." -ForegroundColor Red
    Write-Host "    The error above does NOT say 'double hop' - it looks like access denied." -ForegroundColor Red
    Write-Host "    That ambiguity is what makes this bug hard to diagnose in the field.`n" -ForegroundColor DarkRed
}

# =============================================================================
# SECTION B - The Workaround: Explicit credentials force NTLM
# =============================================================================
# New-CimSession with a PSCredential object bypasses Kerberos and uses NTLM.
# This is the correct pattern for workgroup environments AND is the workaround
# for the double-hop problem when CredSSP is not acceptable.
#
# In a true domain double-hop scenario, the preferred solution is JEA (Just
# Enough Administration) configured on the target machines - but that requires
# AD infrastructure. For the workgroup range, explicit credentials is the
# practical equivalent.

Write-Host "--- SECTION B: Workaround using explicit credentials (forces NTLM) ---" -ForegroundColor Cyan

$credential = Get-Credential -Message "Enter credentials for remote systems (e.g., System-1\student)"

# CimSession with explicit credential - forces NTLM, succeeds in workgroup
Write-Host "`n    Connecting to $hop1 with New-CimSession (NTLM)..." -ForegroundColor Cyan
try {
    $sessionOption = New-CimSessionOption -Protocol WSMAN
    $cimSession = New-CimSession -ComputerName $hop1 -Credential $credential -SessionOption $sessionOption -ErrorAction Stop

    $os = Get-CimInstance -ClassName Win32_OperatingSystem -CimSession $cimSession -ErrorAction Stop
    Write-Host "    [SUCCESS] Connected to $hop1 - OS: $($os.Caption)" -ForegroundColor Green

    # Clean up CIM session
    Remove-CimSession $cimSession

    # PSSession with explicit credential for the second hop demo
    Write-Host "`n    Connecting to $hop1 via PSSession with explicit credential..." -ForegroundColor Cyan
    $psSession = New-PSSession -ComputerName $hop1 -Credential $credential -ErrorAction Stop
    Write-Host "    [SUCCESS] PSSession established to $hop1" -ForegroundColor Green

    # Demonstrate passing credential into the remote session for second hop
    Write-Host "    Attempting second hop to $hop2 from within $hop1 session..." -ForegroundColor Cyan
    $hop2Result = Invoke-Command -Session $psSession -ScriptBlock {
        param($target, $cred)
        $so = New-CimSessionOption -Protocol WSMAN
        $cs = New-CimSession -ComputerName $target -Credential $cred -SessionOption $so -ErrorAction Stop
        $result = Get-CimInstance -ClassName Win32_OperatingSystem -CimSession $cs
        Remove-CimSession $cs
        return $result
    } -ArgumentList $hop2, $credential

    Write-Host "    [SUCCESS] Reached $hop2 via $hop1 - OS: $($hop2Result.Caption)" -ForegroundColor Green
    Remove-PSSession $psSession
}
catch {
    Write-Host "    [FAILED] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "    Verify TrustedHosts includes '$hop1' and '$hop2' on this machine." -ForegroundColor Yellow
    Write-Host "    Run: Set-Item WSMan:\localhost\Client\TrustedHosts -Value 'System-1,System-2,System-3,Depot'" -ForegroundColor Yellow
}

# =============================================================================
# SECTION C - Instructor discussion points (no code to run)
# =============================================================================
Write-Host "`n--- KEY TAKEAWAYS (discuss with class) ---" -ForegroundColor Magenta
Write-Host "  1. Default WinRM/Kerberos cannot delegate credentials beyond the first hop"
Write-Host "  2. The error message does NOT say 'double hop' - it looks like access denied"
Write-Host "  3. Explicit credentials (NTLM) work around this for workgroup environments"
Write-Host "  4. In domain environments, JEA is the PREFERRED solution (least privilege)"
Write-Host "  5. CredSSP works but exposes credentials in memory - NEVER use in production"
Write-Host "  6. ZTA (Zero Trust Architecture) is the DoD architectural answer to this problem"
Write-Host "  7. T1550.003: Attackers exploit Kerberos delegation chains for lateral movement"

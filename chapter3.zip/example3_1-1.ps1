# =============================================================================
# example3_1-1.ps1
# Chapter 3.1 - Debugging PowerShell Scripts
# 170A WOAC Advanced PowerShell
# =============================================================================
# INSTRUCTOR DEMO GUIDE
# This script is intentionally broken in three distinct ways to demonstrate
# the three primary debugging workflows:
#   1. Console debugger (Set-PSBreakpoint)
#   2. VS Code breakpoints (F9 / F5)
#   3. Start-Transcript for session capture
#
# Run this script as-is first so students SEE the errors, then walk through
# each debugging technique to find and fix them.
#
# DEMO FLOW (suggested ~20 min):
#   Step 1 (~3 min)  - Run the script, observe the errors
#   Step 2 (~7 min)  - Use Set-PSBreakpoint to pause and inspect variables
#   Step 3 (~5 min)  - Show VS Code breakpoint at the same line
#   Step 4 (~5 min)  - Wrap in Start-Transcript / Stop-Transcript; show log
# =============================================================================

# --- BUG 1: Typo in variable name -------------------------------------------
# $userName is set here, but $usrName is referenced in the greeting below.
# This will NOT throw a terminating error - it silently produces a blank value.
# This demonstrates why -StrictMode is valuable.
$userName = Read-Host "Enter your name"

# --- BUG 2: Logic error in age check -----------------------------------------
# The intent is to greet users 18 and older differently, but the operator is
# reversed. Any age under 18 triggers the adult greeting instead.
$age = Read-Host "Enter your age"
$age = [int]$age

if ($age -lt 18) {
    # BUG: should be -ge 18 for the adult branch
    Write-Host "Hello, $usrName! Welcome, valued adult user."   # also uses buggy $usrName
} else {
    Write-Host "Hello, $usrName! Parental guidance may be required."
}

# --- BUG 3: Call to a non-existent command -----------------------------------
# This WILL throw a terminating error (CommandNotFoundException).
# Demonstrates the difference between non-terminating and terminating errors,
# and the need for Try/Catch to handle them.
Write-Host "Fetching system report..."
$report = Get-NonExistentCommand -ComputerName localhost

Write-Host "Report result: $report"
Write-Host "Script complete."

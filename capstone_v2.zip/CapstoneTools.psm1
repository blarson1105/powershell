<#
.SYNOPSIS
    CapstoneTools - Reference module for the 170A WOAC Advanced PowerShell capstone assessment.

.DESCRIPTION
    Provides three functions:
      - Get-RemoteProcessInfo   : Query Win32_Process on a remote system via CimSession
      - Get-RemoteServiceInfo   : Query Win32_Service on a remote system via CimSession
      - Install-SysmonRemote    : Deploy Sysmon to a remote system via PSSession

    All functions expect workgroup (non-domain) NTLM authentication using an explicit
    PSCredential. CIM queries use New-CimSession with Negotiate authentication.
    File transfer and command invocation use New-PSSession.

.NOTES
    Reference module for 170A-WOAC-APS-CAP-SCOPE-001 v1.0.
    This is an instructor reference, not a student template.
    Author: 170A WOAC Advanced PowerShell Scripting course
#>

function Get-RemoteProcessInfo {
    <#
    .SYNOPSIS
        Retrieves running process information from a remote Windows system.

    .DESCRIPTION
        Queries the Win32_Process CIM class on a remote system using a CimSession
        configured for NTLM authentication. Returns one PSCustomObject per process.

        This function is designed for workgroup environments. It uses New-CimSession
        with Negotiate authentication because Get-CimInstance -ComputerName defaults
        to Kerberos, which fails outside a domain.

    .PARAMETER ComputerName
        The target remote system name or IP address.

    .PARAMETER Credential
        A PSCredential object with administrative rights on the remote system.

    .EXAMPLE
        $cred = Get-Credential
        Get-RemoteProcessInfo -ComputerName System-1 -Credential $cred

    .OUTPUTS
        PSCustomObject with fields: ComputerName, Name, ProcessId, ParentProcessId,
        CommandLine, ExecutablePath, SessionId, UserName
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential
    )

    $cimSession = $null
    try {
        # Workgroup auth: explicit Negotiate forces NTLM when Kerberos is unavailable.
        # Default CIM auth path fails in workgroups; tested and confirmed 2026-04-18.
        $cimSession = New-CimSession -ComputerName $ComputerName `
                                     -Credential $Credential `
                                     -Authentication Negotiate `
                                     -ErrorAction Stop

        $processes = Get-CimInstance -CimSession $cimSession `
                                     -ClassName Win32_Process `
                                     -ErrorAction Stop

        foreach ($proc in $processes) {
            # Resolve process owner. GetOwner() is an instance method; Invoke-CimMethod runs it
            # against the same session the process instance came from.
            $ownerResult = $null
            try {
                $ownerResult = Invoke-CimMethod -InputObject $proc `
                                                -MethodName GetOwner `
                                                -CimSession $cimSession `
                                                -ErrorAction Stop
            }
            catch {
                # Owner resolution can legitimately fail for system processes (PID 0, 4, etc.)
                # Do not let it fail the whole query.
                $ownerResult = $null
            }

            $userName = if ($ownerResult -and $ownerResult.ReturnValue -eq 0) {
                if ($ownerResult.Domain) {
                    '{0}\{1}' -f $ownerResult.Domain, $ownerResult.User
                } else {
                    $ownerResult.User
                }
            } else {
                $null
            }

            [PSCustomObject]@{
                ComputerName     = $ComputerName
                Name             = $proc.Name
                ProcessId        = $proc.ProcessId
                ParentProcessId  = $proc.ParentProcessId
                CommandLine      = $proc.CommandLine
                ExecutablePath   = $proc.ExecutablePath
                SessionId        = $proc.SessionId
                UserName         = $userName
            }
        }
    }
    catch {
        # Re-throw with context so the orchestrator's try/catch can produce a clean per-target error record.
        throw ("Get-RemoteProcessInfo failed against {0}: {1}" -f $ComputerName, $_.Exception.Message)
    }
    finally {
        if ($cimSession) {
            Remove-CimSession -CimSession $cimSession -ErrorAction SilentlyContinue
        }
    }
}


function Get-RemoteServiceInfo {
    <#
    .SYNOPSIS
        Retrieves service configuration and state from a remote Windows system.

    .DESCRIPTION
        Queries the Win32_Service CIM class on a remote system using a CimSession
        configured for NTLM authentication. Returns one PSCustomObject per service.

        Note: In PowerShell 7, Get-Service -ComputerName was removed. Get-CimInstance
        against Win32_Service is the supported replacement. Property is 'State', not
        'Status' (that is a Get-Service convention that does not apply to CIM).

    .PARAMETER ComputerName
        The target remote system name or IP address.

    .PARAMETER Credential
        A PSCredential object with administrative rights on the remote system.

    .EXAMPLE
        $cred = Get-Credential
        Get-RemoteServiceInfo -ComputerName System-1 -Credential $cred

    .OUTPUTS
        PSCustomObject with fields: ComputerName, Name, DisplayName, State, StartMode,
        StartName, PathName, ProcessId
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential
    )

    $cimSession = $null
    try {
        # Workgroup auth: explicit Negotiate forces NTLM when Kerberos is unavailable.
        # Default CIM auth path fails in workgroups; tested and confirmed 2026-04-18.
        $cimSession = New-CimSession -ComputerName $ComputerName `
                                     -Credential $Credential `
                                     -Authentication Negotiate `
                                     -ErrorAction Stop

        $services = Get-CimInstance -CimSession $cimSession `
                                    -ClassName Win32_Service `
                                    -ErrorAction Stop

        foreach ($svc in $services) {
            [PSCustomObject]@{
                ComputerName = $ComputerName
                Name         = $svc.Name
                DisplayName  = $svc.DisplayName
                State        = $svc.State
                StartMode    = $svc.StartMode
                StartName    = $svc.StartName      # service account (LOLBin detection angle)
                PathName     = $svc.PathName       # full executable path + args
                ProcessId    = $svc.ProcessId
            }
        }
    }
    catch {
        throw ("Get-RemoteServiceInfo failed against {0}: {1}" -f $ComputerName, $_.Exception.Message)
    }
    finally {
        if ($cimSession) {
            Remove-CimSession -CimSession $cimSession -ErrorAction SilentlyContinue
        }
    }
}


function Install-SysmonRemote {
    <#
    .SYNOPSIS
        Deploys Sysmon to a remote Windows system and starts the service.

    .DESCRIPTION
        Transfers the Sysmon binary and configuration file to the remote target using
        Copy-Item -ToSession, then executes the Sysmon installer via Invoke-Command.
        Verifies the Sysmon service is running before returning.

        Uses PSSession (not CimSession) because this operation requires file transfer
        and command invocation, which CimSession does not support.

    .PARAMETER ComputerName
        The target remote system name or IP address.

    .PARAMETER Credential
        A PSCredential object with administrative rights on the remote system.

    .PARAMETER SysmonBinaryPath
        Local path to Sysmon64.exe.

    .PARAMETER SysmonConfigPath
        Local path to the Sysmon configuration XML file.

    .PARAMETER RemoteStagingPath
        Path on the remote system where files are staged. Default: C:\Windows\Temp

    .EXAMPLE
        $cred = Get-Credential
        Install-SysmonRemote -ComputerName System-1 -Credential $cred `
            -SysmonBinaryPath C:\Tools\Sysmon64.exe `
            -SysmonConfigPath C:\Tools\sysmonconfig.xml

    .OUTPUTS
        PSCustomObject with fields: ComputerName, Status, ServiceState, Message
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$ComputerName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Credential,

        [Parameter(Mandatory)]
        [string]$SysmonBinaryPath,

        [Parameter(Mandatory)]
        [string]$SysmonConfigPath,

        [string]$RemoteStagingPath = 'C:\Windows\Temp'
    )

    # Fail early if the local artifacts are not present.
    if (-not (Test-Path $SysmonBinaryPath)) {
        throw "Sysmon binary not found: $SysmonBinaryPath"
    }
    if (-not (Test-Path $SysmonConfigPath)) {
        throw "Sysmon config not found: $SysmonConfigPath"
    }

    $session = $null
    try {
        $session = New-PSSession -ComputerName $ComputerName `
                                 -Credential $Credential `
                                 -ErrorAction Stop

        # Transfer artifacts to the target. -ToSession uses the WinRM transport already established.
        Copy-Item -Path $SysmonBinaryPath `
                  -Destination $RemoteStagingPath `
                  -ToSession $session `
                  -Force `
                  -ErrorAction Stop

        Copy-Item -Path $SysmonConfigPath `
                  -Destination $RemoteStagingPath `
                  -ToSession $session `
                  -Force `
                  -ErrorAction Stop

        $binaryName = Split-Path $SysmonBinaryPath -Leaf
        $configName = Split-Path $SysmonConfigPath -Leaf
        $remoteBinary = Join-Path $RemoteStagingPath $binaryName
        $remoteConfig = Join-Path $RemoteStagingPath $configName

        # Run installer on the remote. -accepteula avoids interactive prompt; -i installs with config.
        $installResult = Invoke-Command -Session $session -ScriptBlock {
            param($Binary, $Config)
            $proc = Start-Process -FilePath $Binary `
                                  -ArgumentList "-accepteula", "-i", "`"$Config`"" `
                                  -Wait -PassThru -NoNewWindow
            $proc.ExitCode
        } -ArgumentList $remoteBinary, $remoteConfig

        if ($installResult -ne 0) {
            throw "Sysmon installer exited with code $installResult on $ComputerName"
        }

        # Verify service state post-install. Running = deploy succeeded.
        $serviceState = Invoke-Command -Session $session -ScriptBlock {
            $svc = Get-Service -Name 'Sysmon64' -ErrorAction SilentlyContinue
            if (-not $svc) { $svc = Get-Service -Name 'Sysmon' -ErrorAction SilentlyContinue }
            if ($svc) { $svc.Status.ToString() } else { 'NotFound' }
        }

        [PSCustomObject]@{
            ComputerName = $ComputerName
            Status       = if ($serviceState -eq 'Running') { 'Success' } else { 'Failed' }
            ServiceState = $serviceState
            Message      = "Sysmon deployed; service state is $serviceState"
        }
    }
    catch {
        [PSCustomObject]@{
            ComputerName = $ComputerName
            Status       = 'Failed'
            ServiceState = 'Unknown'
            Message      = $_.Exception.Message
        }
    }
    finally {
        if ($session) {
            Remove-PSSession -Session $session -ErrorAction SilentlyContinue
        }
    }
}


Export-ModuleMember -Function Get-RemoteProcessInfo, Get-RemoteServiceInfo, Install-SysmonRemote

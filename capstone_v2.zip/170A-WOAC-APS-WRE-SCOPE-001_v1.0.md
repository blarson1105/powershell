# Written Assessment Scope Contract

**Document ID:** 170A-WOAC-APS-WRE-SCOPE-001
**Version:** 1.0 (Draft — Pending Approval)
**Effective Date:** 2026-04-18
**Supersedes:** None

---

## 1. Course Identification

| Field | Value |
|---|---|
| Course | 170A Warrant Officer Advanced Course — Advanced PowerShell Scripting |
| Proponent | United States Army Cyber Center of Excellence (USACyCoE) |
| Delivery Location | Fort Eisenhower |
| Course Duration | Five (5) days |

---

## 2. Authority

This document derives its scope authority from the *170A Critical Task and Site Selection Board (CTSSB) Output*, dated 16 February 2024, Module 1, Topic: Advanced PowerShell (pp. 48–49). All assessment requirements defined herein trace to that source.

---

## 3. Purpose

This contract establishes the scope, structure, and evaluation criteria for the Advanced PowerShell written knowledge assessment administered to students enrolled in the 170A Warrant Officer Advanced Course. It defines the authoritative assessment of CTSSB knowledge items and the role of formative quizzes. This document is the controlling authority for written assessment scope; no question coverage may be added, removed, or modified except in accordance with the change control procedure in Section 12.

---

## 4. Definitions

| Term | Definition |
|---|---|
| Final Exam | The cumulative written assessment administered at end of Day 4. The authoritative instrument for CTSSB knowledge assessment. |
| Formative Quiz | A non-authoritative, low-stakes quiz administered at the end of a chapter for learning reinforcement. |
| Blueprint | The distribution of examination questions across CTSSB knowledge items. |
| Cognitive Verb | The action verb used in a CTSSB knowledge statement (e.g., "Understand," "Discuss," "Contrast," "Compare"), which establishes the expected depth of student demonstration. |
| Recognition Depth | Ability to identify or select a correct conceptual statement from among alternatives. |
| Recall and Application Depth | Ability to produce a correct response or apply a concept to a described scenario. |
| Differentiation Depth | Ability to identify distinctions between two or more concepts. |
| Explain-in-Context Depth | Ability to describe a concept as it applies to a given operational scenario. |

---

## 5. Learning Outcome (Verbatim CTSSB)

> "In a classroom environment given a Microsoft Windows system with PowerShell, the student will demonstrate advanced PowerShell techniques."

---

## 6. Assessment Model

6.1 **Hybrid Structure.** Knowledge demonstration is supported by a hybrid of formative and authoritative assessments:
  - (a) Formative quizzes at the end of each chapter support learning reinforcement. These are non-authoritative.
  - (b) A single cumulative final exam is the authoritative instrument for CTSSB knowledge assessment.

6.2 **Final Exam Timing.** The final exam is administered at end of Day 4, prior to the commencement of Day 5 capstone work.

6.3 **Individual Assessment.** The final exam is individual. Collaboration is not permitted.

6.4 **Question Blueprint.** The final exam applies a flat distribution across CTSSB knowledge items. No operational weighting is applied.

---

## 7. CTSSB Knowledge Items Assessed (Verbatim)

The final exam assesses all eleven (11) knowledge statements listed in the CTSSB under Topic: Advanced PowerShell.

| Identifier | CTSSB Knowledge Statement (Verbatim) | Cognitive Verb |
|---|---|---|
| K1 | "Understand .NET usage within PowerShell" | Understand |
| K2 | "Understand advanced debugging techniques available for PowerShell" | Understand |
| K3 | "Discuss the double-hop problem as it pertains to Windows Remote Management" | Discuss |
| K4 | "Contrast the different language modes in PowerShell" | Contrast |
| K5 | "Understand PowerShell performance techniques i.e. parallel jobs" | Understand |
| K6 | "Compare common attacker techniques using PowerShell and how to defend against them" | Compare |
| K7 | "Understand the concepts of PowerShell Desired State Configuration (Configuration as code)" | Understand |
| K8 | "Discuss common problems encountered when executing remote PowerShell scripts on many remote systems" | Discuss |
| K9 | "Understand script repurposing" | Understand |
| K10 | "Understand API interactions utilizing PowerShell" | Understand |
| K11 | "Understand PowerShell integration with Microsoft Azure" | Understand |

---

## 8. Depth Calibration

8.1 **Cognitive Verb Authority.** The depth at which each knowledge item is assessed shall correspond to the cognitive verb used by the CTSSB for that item.

8.2 **Depth Assignments.** Each knowledge item is assessed at the depth specified below:

| Identifier | Cognitive Verb | Depth Assigned | Basis |
|---|---|---|---|
| K1 | Understand | Recall and Application | Course provides hands-on instruction. |
| K2 | Understand | Recall and Application | Course provides hands-on instruction. |
| K3 | Discuss | Explain-in-Context | CTSSB verb requires contextual explanation. |
| K4 | Contrast | Differentiation | CTSSB verb requires comparison between language modes. |
| K5 | Understand | Recall and Application | Course provides hands-on instruction. |
| K6 | Compare | Differentiation | CTSSB verb requires explicit comparison. |
| K7 | Understand | Recognition | Course provides conceptual instruction without hands-on exercise. CTSSB verb "Understand" does not require "Apply" or "Demonstrate." |
| K8 | Discuss | Explain-in-Context | CTSSB verb requires contextual explanation. |
| K9 | Understand | Recall and Application | Course provides hands-on instruction. |
| K10 | Understand | Recognition | Course provides conceptual instruction without hands-on exercise. CTSSB verb "Understand" does not require "Apply" or "Demonstrate." |
| K11 | Understand | Recognition | Course provides conceptual instruction without hands-on exercise. CTSSB verb "Understand" does not require "Apply" or "Demonstrate." |

---

## 9. Examination Blueprint

9.1 **Total Question Count.** The final exam shall contain between twenty-five (25) and thirty (30) questions.

9.2 **Distribution.** Questions are distributed across the eleven (11) knowledge items as follows:

| Identifier | Target Question Count | Appropriate Question Types |
|---|---|---|
| K1 | 2–3 | Multiple choice, short answer |
| K2 | 2–3 | Multiple choice, scenario-based |
| K3 | 2–3 | Scenario-based, short answer |
| K4 | 2–3 | Multiple choice, matching |
| K5 | 2–3 | Multiple choice, code snippet analysis |
| K6 | 2–3 | Multiple choice, scenario-based |
| K7 | 2 | Multiple choice |
| K8 | 2–3 | Scenario-based, short answer |
| K9 | 2 | Multiple choice, code snippet analysis |
| K10 | 2 | Multiple choice |
| K11 | 2 | Multiple choice |

9.3 **Flexibility.** Final question counts within the 25–30 range are determined by the question depth required to assess each item in accordance with Section 8.

---

## 10. Formative Quizzes

10.1 **Purpose.** Formative quizzes are administered at the end of each course chapter to support learning reinforcement. Formative quizzes are not authoritative for CTSSB knowledge assessment.

10.2 **Chapter-to-Knowledge Mapping.** Formative quiz content aligns to the knowledge items introduced in each chapter:

| Chapter | Knowledge Items Addressed |
|---|---|
| 1 | K1, K2 |
| 2 | K1 |
| 3 | K3, K4, K6, K7, K8, K10, K11 |
| 4 | K5 |
| 5 | K8, K9 |
| 6 | Integrative review |

10.3 **Quiz Design Parameters.** Formative quizzes permit multiple attempts. Students receive feedback on incorrect responses. Formative quiz questions do not appear on the final exam.

---

## 11. Question Quality Standards

11.1 Every question on the final exam shall satisfy the following:

  (a) **Traceability.** The question maps to exactly one CTSSB knowledge item.
  (b) **Single Correct Answer.** For non-matching question types, exactly one answer choice is correct. Compliance shall be verified via automated audit prior to administration.
  (c) **Depth Alignment.** Question depth matches the cognitive verb specified in Section 8 for the mapped knowledge item.
  (d) **Scenario Preference.** Scenario-based framings are preferred over abstract recall where the knowledge item supports scenario presentation.
  (e) **Distractor Validity.** Incorrect answer choices represent plausible misconceptions rather than surface-level wordplay.
  (f) **Format Hygiene.** Questions drafted in word-processing or PDF applications shall be manually retyped prior to import to ensure removal of smart quotation marks, em-dashes, and other format artifacts incompatible with GIFT import.

---

## 12. Change Control

12.1 **Authority.** This contract is the sole authority for written assessment scope. No scope change is effective except through the procedure in this section.

12.2 **Required Elements.** A proposed scope change shall include:
  - (a) Written statement of the proposed change;
  - (b) Traceability citation to a specific CTSSB Knowledge or Skill statement;
  - (c) Written approval from both instructors of record.

12.3 **Non-Traceable Proposals.** A proposed change that cannot satisfy 12.2(b) shall not be incorporated into this contract. Such proposals may be incorporated into formative course materials outside the scope of the final exam.

12.4 **Documentation.** All approved changes shall be recorded in Section 13 with effective date.

---

## 13. Revision History

| Version | Effective Date | Summary of Change | Approved By |
|---|---|---|---|
| 1.0 | 2026-04-18 | Initial issue. | [Signature Block] |

---

## 14. Related Documents

- *170A CTSSB Output*, 16 February 2024 — Module 1, Topic: Advanced PowerShell
- Capstone Assessment Scope Contract (Document ID: 170A-WOAC-APS-CAP-SCOPE-001)
- Final Exam Blueprint (to be developed)
- Final Exam Question Bank (to be developed)

---

## 15. Approval

This contract is approved for implementation as of the effective date specified above.

| Role | Name | Signature | Date |
|---|---|---|---|
| Primary Instructor | | | |
| Co-Instructor | | | |
| Course Director / Approving Authority | | | |

---

*End of Document — 170A-WOAC-APS-WRE-SCOPE-001 v1.0*

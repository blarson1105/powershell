# Capstone Assessment Scope Contract

**Document ID:** 170A-WOAC-APS-CAP-SCOPE-001
**Version:** 1.0 (Draft — Pending Approval)
**Effective Date:** 2026-04-18
**Supersedes:** None

---

## 1. Course Identification

| Field | Value |
|---|---|
| Course | 170A Warrant Officer Advanced Course — Advanced PowerShell Scripting |
| Proponent | United States Army Cyber Center of Excellence (USACyCoE) |
| Delivery Location | Fort Eisenhower |
| Course Duration | Five (5) days |

---

## 2. Authority

This document derives its scope authority from the *170A Critical Task and Site Selection Board (CTSSB) Output*, dated 16 February 2024, Module 1, Topic: Advanced PowerShell (pp. 48–49). All assessment requirements defined herein trace to that source.

---

## 3. Purpose

This contract establishes the scope, structure, and evaluation criteria for the Advanced PowerShell skills assessment (hereafter: the capstone) administered to students enrolled in the 170A Warrant Officer Advanced Course. It defines the deliverables required and the rubric against which those deliverables are evaluated. This document is the controlling authority for capstone scope; no assessment item may be added, removed, or modified except in accordance with the change control procedure in Section 10.

---

## 4. Definitions

| Term | Definition |
|---|---|
| Capstone | The final skills assessment administered on Day 5 of the course. |
| CTSSB | Critical Task and Site Selection Board. |
| Rubric Item | A required evaluation criterion against which the capstone is graded. |
| Module | A PowerShell file (`.psm1`) containing one or more functions, intended for import and reuse. |
| Orchestrator | A PowerShell script (`.ps1`) that coordinates execution of module functions. |
| Remote System | A Windows host accessible to the student's workstation via Windows Remote Management. |

---

## 5. Learning Outcome (Verbatim CTSSB)

> "In a classroom environment given a Microsoft Windows system with PowerShell, the student will demonstrate advanced PowerShell techniques."

---

## 6. CTSSB Skills Traceability

The capstone assesses all four (4) skill statements listed in the CTSSB under Topic: Advanced PowerShell.

| Identifier | CTSSB Skill Statement (Verbatim) |
|---|---|
| S1 | "Develop a PowerShell script to gather specified information from multiple remote systems" |
| S2 | "Create a PowerShell script that can run multiple jobs in parallel" |
| S3 | "Develop a PowerShell script to deploy an application to a remote system" |
| S4 | "Integrate advanced debugging techniques to analyze PowerShell scripts" |

---

## 7. Assessment Model

7.1 **Single Graded Event.** The capstone constitutes the sole graded assessment for the Advanced PowerShell topic.

7.2 **Individual Assessment.** Each student submits their own capstone artifacts. Pair or team submissions are not permitted.

7.3 **Requirements Publication.** Capstone requirements are made available to students at the start of Day 1. Students are expected to develop capstone artifacts throughout the course in parallel with chapter exercises.

7.4 **Scaffolding.** Chapter 5 hands-on exercises provide the component skills required for capstone completion. The course does not guarantee capstone readiness independent of student engagement with chapter exercises.

---

## 8. Required Deliverables

Students shall submit two (2) artifacts:

| Artifact | File Type | Required Contents |
|---|---|---|
| Tools module | `.psm1` | Two (2) `Get-*` functions addressing S1; one (1) application deployment function addressing S3 |
| Orchestrator script | `.ps1` | Module import; parallel job execution addressing S2; structured error handling addressing S4 |

File names are not prescribed. Structure and contents are prescribed as specified above.

---

## 9. Rubric

The following four (4) rubric items are required. Each traces to exactly one CTSSB skill. All four items must be satisfied for the capstone to be assessed as demonstrating the required skill.

| ID | Skill | Criterion | Pass Condition |
|---|---|---|---|
| R1 | S1 | Module contains two or more `Get-*` functions that query remote systems | Each function accepts a `-ComputerName` parameter, returns a `PSCustomObject`, and successfully retrieves data from at least two (2) distinct remote hosts. |
| R2 | S2 | Orchestrator executes module functions in parallel | Jobs are dispatched via `Start-Job` or `ForEach-Object -Parallel`. Execution is demonstrably concurrent. |
| R3 | S3 | Module contains a function that deploys Sysmon to a remote system | The Sysmon binary and configuration file are transferred to the target. The Sysmon service is installed and running on the target upon completion. State is verifiable via `Get-Service` executed against the target. |
| R4 | S4 | Script handles errors without terminating execution | `try`/`catch` blocks enclose remote operations and deployment logic. Script execution completes regardless of per-target failures. Output differentiates successful targets from failed targets. |

---

## 10. Change Control

10.1 **Authority.** This contract is the sole authority for capstone assessment scope. No scope change is effective except through the procedure in this section.

10.2 **Required Elements.** A proposed scope change shall include:
  - (a) Written statement of the proposed change;
  - (b) Traceability citation to a specific CTSSB Knowledge or Skill statement;
  - (c) Written approval from both instructors of record.

10.3 **Non-Traceable Proposals.** A proposed change that cannot satisfy 10.2(b) shall not be incorporated into this contract. Such proposals may be incorporated into formative course materials outside the scope of capstone assessment.

10.4 **Documentation.** All approved changes shall be recorded in Section 11 with effective date.

---

## 11. Revision History

| Version | Effective Date | Summary of Change | Approved By |
|---|---|---|---|
| 1.0 | 2026-04-18 | Initial issue. | [Signature Block] |

---

## 12. Related Documents

- *170A CTSSB Output*, 16 February 2024 — Module 1, Topic: Advanced PowerShell
- Written Assessment Scope Contract (Document ID: 170A-WOAC-APS-WRE-SCOPE-001)
- Capstone Reference Implementation (to be developed)

---

## 13. Approval

This contract is approved for implementation as of the effective date specified above.

| Role | Name | Signature | Date |
|---|---|---|---|
| Primary Instructor | | | |
| Co-Instructor | | | |
| Course Director / Approving Authority | | | |

---

*End of Document — 170A-WOAC-APS-CAP-SCOPE-001 v1.0*
